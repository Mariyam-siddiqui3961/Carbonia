import SwiftUI
import SceneKit

struct CarbonAtomView: UIViewRepresentable {
    @Environment(\.colorScheme) var colorScheme

    func makeUIView(context: Context) -> SCNView {
        let scnView = SCNView()
        scnView.scene = CarbonAtomScene.createScene(isDarkMode: colorScheme == .dark)
        scnView.allowsCameraControl = true
        scnView.autoenablesDefaultLighting = true
        scnView.preferredFramesPerSecond = 60
        scnView.backgroundColor = .clear
        scnView.isOpaque = false
        return scnView
    }

    func updateUIView(_ uiView: SCNView, context: Context) {
        // Rebuild scene when color scheme changes
        uiView.scene = CarbonAtomScene.createScene(isDarkMode: colorScheme == .dark)
    }
}

struct CarbonAtomView_Previews: PreviewProvider {
    static var previews: some View {
        CarbonAtomView()
            .frame(width: 300, height: 300)
    }
}
