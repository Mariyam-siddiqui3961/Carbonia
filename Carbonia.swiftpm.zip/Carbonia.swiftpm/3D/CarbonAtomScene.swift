import SceneKit
import SwiftUI

#if os(macOS)
    private typealias PlatformColor = NSColor
#else
    private typealias PlatformColor = UIColor
#endif

class CarbonAtomScene {
    static func createScene(isDarkMode: Bool = false) -> SCNScene {
        let scene = SCNScene()
        
        // Set transparent background for the scene
        scene.background.contents = PlatformColor.clear
        
        // --- Nucleus (Protons & Neutrons) ---
        // Carbon-12 has 6 protons and 6 neutrons.
        // We'll create a cluster of spheres.
        let nucleusNode = SCNNode()
        
        let particleRadius: CGFloat = 0.5
        let particles = 12 // 6 protons + 6 neutrons
        
        // Carbon atom representation: Dark Gray / Black
        
        for i in 0..<particles {
            let sphere = SCNSphere(radius: particleRadius)
            let material = SCNMaterial()
            if i % 2 == 0 {
                material.diffuse.contents = PlatformColor.black // Proton (Black for carbon convention)
            } else {
                material.diffuse.contents = PlatformColor.darkGray // Neutron (Dark Gray)
            }
            // Add some specularity to make it look like a shiny plastic/3D model
            material.specular.contents = PlatformColor.white
            material.shininess = 0.5

            sphere.materials = [material]
            
            let node = SCNNode(geometry: sphere)
            
            // Randomly position them in a small cluster
            // Using a simple random distribution within a sphere
            let r = CGFloat.random(in: 0...0.6)
            let theta = CGFloat.random(in: 0...2 * .pi)
            let phi = CGFloat.random(in: 0...CGFloat.pi)
            
            let x = r * sin(phi) * cos(theta)
            let y = r * sin(phi) * sin(theta)
            let z = r * cos(phi)
            
            node.position = SCNVector3(x, y, z)
            nucleusNode.addChildNode(node)
        }
        
        scene.rootNode.addChildNode(nucleusNode)
        
        // --- Electrons ---
        // Carbon has 2 shells: K=2, L=4.
        // Or we can just show them orbiting.
        // Let's make 2 electrons in inner shell, 4 in outer shell.
        
        let electronRadius: CGFloat = 0.15
        let electronColor = PlatformColor.cyan

        // Shell orbit ring color: white in dark mode, black in light mode
        let shellColor = isDarkMode
            ? PlatformColor.white.withAlphaComponent(0.75)
            : PlatformColor.black.withAlphaComponent(0.6)
        
        // Inner Shell
        addElectronShell(scene: scene, radius: 2.5, electrons: 2, color: electronColor, particleRadius: electronRadius, shellColor: shellColor)
        
        // Outer Shell
        addElectronShell(scene: scene, radius: 4.0, electrons: 4, color: electronColor, particleRadius: electronRadius, shellColor: shellColor)

        // --- Lighting ---
        let omniLightNode = SCNNode()
        omniLightNode.light = SCNLight()
        omniLightNode.light!.type = .omni
        omniLightNode.light!.color = PlatformColor(white: 1.0, alpha: 1.0)
        omniLightNode.position = SCNVector3(x: 10, y: 10, z: 10)
        scene.rootNode.addChildNode(omniLightNode)

        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = PlatformColor(white: 0.3, alpha: 1.0)
        scene.rootNode.addChildNode(ambientLightNode)
        
        return scene
    }
    
    private static func addElectronShell(scene: SCNScene, radius: CGFloat, electrons: Int, color: PlatformColor, particleRadius: CGFloat, shellColor: PlatformColor) {
        let shellNode = SCNNode()
        // Visualize the shell path (orbit) - Optional, adds to the "scientific" look
        let msgGeometry = SCNTorus(ringRadius: radius, pipeRadius: 0.02)
        let tubeMaterial = SCNMaterial()
        tubeMaterial.diffuse.contents = shellColor
        msgGeometry.materials = [tubeMaterial]
        let orbitNode = SCNNode(geometry: msgGeometry)
        shellNode.addChildNode(orbitNode)
        
        for i in 0..<electrons {
            let sphere = SCNSphere(radius: particleRadius)
            let material = SCNMaterial()
            material.diffuse.contents = color
            material.emission.contents = color // Make them glow slightly
            sphere.materials = [material]
            
            let electronNode = SCNNode(geometry: sphere)
            
            // Distribute electrons along the ring
            let angle = (CGFloat(i) / CGFloat(electrons)) * 2 * .pi
            let x = radius * cos(angle)
            let z = radius * sin(angle)
            
            electronNode.position = SCNVector3(x, 0, z)
            shellNode.addChildNode(electronNode)
        }
        
        // Rotate the shell randomly to make it look 3D and dynamic
        shellNode.eulerAngles = SCNVector3(
            CGFloat.random(in: 0...2 * .pi),
            CGFloat.random(in: 0...2 * .pi),
            0
        )
        
        // Add animation to rotate the shell
        let rotation = SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: Double.random(in: 5...10))
        let repeatAction = SCNAction.repeatForever(rotation)
        shellNode.runAction(repeatAction)
        
        scene.rootNode.addChildNode(shellNode)
    }
}
