import SwiftUI

struct Theme {
    // Standard backgrounds
    static let systemBackground = Color(.systemBackground)
    static let secondarySystemBackground = Color(.secondarySystemGroupedBackground)
    static let groupedBackground = Color(.systemGroupedBackground)
    
    // Materials
    static let thinMaterial = Material.thin
    static let regularMaterial = Material.regular
    
    // Atom colors (refined for better contrast on system backgrounds)
    static let carbon = Color.primary
    static let hydrogen = Color.secondary
    
    // Accent
    static let accent = Color.accentColor
    
    // Standard Card Style
    static func cardBackground() -> some View {
        RoundedRectangle(cornerRadius: 16)
            .fill(secondarySystemBackground)
            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
    
    // Fonts
    static func titleFont() -> Font {
        .title.bold()
    }
    
    static func subtitleFont() -> Font {
        .headline
    }
    
    static func bodyFont() -> Font {
        .body
    }
}
