// ContentView.swift is intentionally left minimal.
// Navigation is handled by RootView in MyApp.swift.
import SwiftUI

// Kept for preview compatibility only.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        RootView()
    }
}
