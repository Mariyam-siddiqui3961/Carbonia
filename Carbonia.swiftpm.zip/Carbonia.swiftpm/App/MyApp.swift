import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            if #available(iOS 17.0, *) {
                RootView()
            } else {
                Text("Carbon Explorer requires iOS 17 or later.")
                    .padding()
            }
        }
    }
}

/// Root view that uses a state-based switcher so the Welcome screen
/// doesn't leave a stale NavigationStack entry behind.
@available(iOS 17.0, *)
struct RootView: View {
    @State private var hasLaunched = false

    var body: some View {
        if hasLaunched {
            MainTabView()
                .transition(.opacity)
        } else {
            NavigationStack {
                WelcomeView(onStart: {
                    withAnimation(.easeInOut(duration: 0.4)) {
                        hasLaunched = true
                    }
                })
            }
            .transition(.opacity)
        }
    }
}
