import SwiftUI

struct WelcomeView: View {
    var onStart: () -> Void

    @State private var atomScale: CGFloat = 0.85
    @State private var titleOpacity: Double = 0
    @State private var subtitleOpacity: Double = 0
    @State private var buttonOpacity: Double = 0

    var body: some View {
        ZStack {
            // Background
            Color(.systemGroupedBackground)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer(minLength: 20)

                // 3D Carbon Atom
                CarbonAtomView()
                    .frame(width: 320, height: 320)
                    .scaleEffect(atomScale)
                    .accessibilityLabel("Animated 3D carbon atom model")
                    .accessibilityHint("Interactive model — drag to rotate")

                Spacer(minLength: 32)

                // Title + Tagline
                VStack(spacing: 12) {
                    Text("Carbonia")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundStyle(Color.primary)
                        .opacity(titleOpacity)

                    Text("Explore allotropes, hydrocarbons, and\nIUPAC naming-interactively.")
                        .font(.body)
                        .foregroundStyle(Color.secondary)
                        .multilineTextAlignment(.center)
                        .lineSpacing(4)
                        .padding(.horizontal, 32)
                        .opacity(subtitleOpacity)
                }

                Spacer(minLength: 48)

                // CTA Button
                Button(action: onStart) {
                    Text("Start Exploring")
                        .font(.headline)
                        .foregroundStyle(Color.white)
                        .padding(.horizontal, 36)
                        .padding(.vertical, 16)
                        .background(Color.blue, in: Capsule())
                }
                .buttonStyle(.plain)
                .opacity(buttonOpacity)
                .accessibilityLabel("Start Exploring")
                .accessibilityHint("Navigates to the main learning screen")

                Spacer(minLength: 40)
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            withAnimation(.spring(duration: 0.7, bounce: 0.3)) {
                atomScale = 1.0
            }
            withAnimation(.easeOut(duration: 0.6).delay(0.3)) {
                titleOpacity = 1
            }
            withAnimation(.easeOut(duration: 0.6).delay(0.5)) {
                subtitleOpacity = 1
            }
            withAnimation(.easeOut(duration: 0.6).delay(0.7)) {
                buttonOpacity = 1
            }
        }
    }
}


