import SwiftUI

// MARK: - Learn Menu View

@available(iOS 17.0, *)
struct LearnMenuView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                MenuCard(
                    title: "Carbon",
                    subtitle: "Atomic structure, bonding and properties",
                    imageName: "carbon_3d",
                    destination: AnyView(CarbonElementView())
                )

                MenuCard(
                    title: "Allotropes of Carbon",
                    subtitle: "Diamond, graphite, fullerene & more",
                    imageName: "allotropes_3d",
                    destination: AnyView(AllotropesView())
                )

                MenuCard(
                    title: "Hydrocarbon Explorer",
                    subtitle: "Alkanes, alkenes & alkynes",
                    imageName: "hydrocarbons_3d",
                    destination: AnyView(HydrocarbonView())
                )

                MenuCard(
                    title: "Build a Molecule",
                    subtitle: "Construct carbon compounds",
                    imageName: "builder_3d",
                    destination: AnyView(MoleculeBuilderView())
                )
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 24)
        }
        .scrollIndicators(.hidden)
        .navigationTitle("Learn")
        .navigationBarTitleDisplayMode(.large)
    }
}

// MARK: - Menu Card

@available(iOS 17.0, *)
struct MenuCard: View {
    let title: String
    let subtitle: String
    let imageName: String?
    let destination: AnyView

    var body: some View {
        NavigationLink(destination: destination) {
            cardContent
        }
        .buttonStyle(.plain)
    }

    private var cardContent: some View {
        ZStack(alignment: .bottomLeading) {
            if let name = imageName {
                Image(name)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 160)
                    .clipped()
            }

            LinearGradient(
                colors: [Color.black.opacity(0.55), Color.clear],
                startPoint: .bottom,
                endPoint: .center
            )

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(Color.white.opacity(0.82))
            }
            .padding(18)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 160)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: Color.black.opacity(0.12), radius: 10, x: 0, y: 4)
    }
}
