import SwiftUI
import SceneKit

@available(iOS 17.0, *)
struct AllotropeDetailView: View {
    let allotrope: Allotrope

    @State private var showAIChat = false
    @State private var modelScale: CGFloat = 1.0
    @State private var conductivityMode = false
    @State private var showConductivityExplanation = false
    @State private var conductivityPulse = false

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {

                    // 3D Interactive Structure
                    ZStack(alignment: .bottom) {
                        Allotrope3DView(
                            allotropeName: allotrope.name,
                            scale: $modelScale,
                            conductivityMode: conductivityMode,
                            conductsElectricity: allotrope.conductsElectricity
                        )
                        .frame(height: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color(.secondarySystemGroupedBackground))
                        )
                        .overlay(alignment: .topTrailing) {
                            // Gesture hints
                            VStack(spacing: 4) {
                                Label("Drag to rotate", systemImage: "arrow.up.and.down.and.arrow.left.and.right")
                                Label("Pinch to zoom", systemImage: "arrow.up.left.and.arrow.down.right")
                            }                            .font(.caption2)
                            .foregroundStyle(Color.secondary)
                            .padding(10)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))
                            .padding(10)
                        }
                        .overlay(alignment: .topLeading) {
                            // Conductivity badge — only visible when mode is ON
                            if conductivityMode {
                                ConductivityBadge(conducts: allotrope.conductsElectricity, active: conductivityMode)
                                    .padding(12)
                                    .transition(.scale.combined(with: .opacity))
                            }
                        }

                        // Conductivity toggle bar pinned at bottom of 3D view
                        ConductivityToggleBar(
                            conductsElectricity: allotrope.conductsElectricity,
                            isOn: $conductivityMode
                        )
                        .padding(.horizontal, 16)
                        .padding(.bottom, 12)
                    }

                    // Conductivity explanation card (shown when mode is active)
                    if conductivityMode {
                        ConductivityExplanationCard(
                            conducts: allotrope.conductsElectricity,
                            explanation: allotrope.conductivityExplanation
                        )
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }

                    // Structure
                    DetailSection(title: "Structure") {
                        Text(allotrope.structure)
                            .foregroundStyle(Color.secondary)
                    }

                    // Properties
                    DetailSection(title: "Properties") {
                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(allotrope.properties, id: \.self) { prop in
                                HStack(alignment: .top, spacing: 8) {
                                    Image(systemName: "circle.fill")
                                        .font(.system(size: 6))
                                        .foregroundStyle(Color.secondary)
                                        .padding(.top, 6)
                                    Text(prop)
                                        .font(.subheadline)
                                        .foregroundStyle(Color.secondary)
                                }
                            }
                        }
                    }

                    // Uses
                    DetailSection(title: "Uses") {
                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(allotrope.uses, id: \.self) { use in
                                Label(use, systemImage: "checkmark.circle.fill")
                                    .font(.subheadline)
                                    .foregroundStyle(Color.secondary)
                            }
                        }
                    }
                }
                .padding()
                .padding(.bottom, 80)
                .animation(.spring(response: 0.4, dampingFraction: 0.75), value: conductivityMode)
            }
            .scrollIndicators(.hidden)
            .background(Theme.groupedBackground)

            // Floating AI Assistant button
            Button {
                showAIChat = true
            } label: {
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [
                                    Color(red: 1.0,  green: 0.72, blue: 0.3),
                                    Color(red: 0.95, green: 0.38, blue: 0.55),
                                    Color(red: 0.35, green: 0.62, blue: 1.0)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 60, height: 60)
                        .shadow(color: Color(red: 0.95, green: 0.38, blue: 0.55).opacity(0.45),
                                radius: 10, x: 0, y: 4)
                    Image(systemName: "atom")
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundStyle(Color.white)
                }
            }
            .padding(.trailing, 24)
            .padding(.bottom, 28)
            .accessibilityLabel("Ask AI Assistant about \(allotrope.name)")
            .sheet(isPresented: $showAIChat) {
                AllotropeChatView(allotrope: allotrope)
            }
        }
        .navigationTitle(allotrope.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Conductivity Badge

struct ConductivityBadge: View {
    let conducts: Bool
    let active: Bool

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: conducts ? "bolt.fill" : "bolt.slash.fill")
                .font(.caption.bold())
            Text(conducts ? "Conductor" : "Insulator")
                .font(.caption.bold())
        }
        .foregroundStyle(conducts ? Color(red: 0.1, green: 0.85, blue: 0.35) : Color(red: 1.0, green: 0.35, blue: 0.3))
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
                .overlay(
                    Capsule().stroke(
                        conducts
                            ? Color(red: 0.1, green: 0.85, blue: 0.35).opacity(active ? 0.9 : 0.4)
                            : Color(red: 1.0, green: 0.35, blue: 0.3).opacity(active ? 0.9 : 0.4),
                        lineWidth: 1.5
                    )
                )
        )
        .scaleEffect(active ? 1.05 : 1.0)
        .animation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true), value: active)
    }
}

// MARK: - Conductivity Toggle Bar

struct ConductivityToggleBar: View {
    let conductsElectricity: Bool
    @Binding var isOn: Bool

    private var accentColor: Color {
        conductsElectricity
            ? Color(red: 0.1, green: 0.85, blue: 0.35)
            : Color(red: 1.0, green: 0.3, blue: 0.25)
    }

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                isOn.toggle()
            }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: isOn
                      ? (conductsElectricity ? "bolt.fill" : "bolt.slash.fill")
                      : "powerplug")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(isOn ? accentColor : .secondary)
                    .contentTransition(.symbolEffect(.replace))

                Text(isOn ? "Conductivity Mode: ON" : "Show Conductivity")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(isOn ? accentColor : Color.primary)

                Spacer()

                // Toggle pill
                ZStack(alignment: isOn ? .trailing : .leading) {
                    Capsule()
                        .fill(isOn ? accentColor : Color(.systemGray4))
                        .frame(width: 44, height: 26)
                    Circle()
                        .fill(Color.white)
                        .frame(width: 20, height: 20)
                        .shadow(radius: 2)
                        .padding(3)
                }
                .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isOn)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(isOn ? accentColor.opacity(0.5) : Color.clear, lineWidth: 1.5)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Conductivity Explanation Card

struct ConductivityExplanationCard: View {
    let conducts: Bool
    let explanation: String

    private var accentColor: Color {
        conducts ? Color(red: 0.1, green: 0.85, blue: 0.35) : Color(red: 1.0, green: 0.3, blue: 0.25)
    }

    private var icon: String {
        conducts ? "bolt.fill" : "bolt.slash.fill"
    }

    private var title: String {
        conducts ? "Conducts Electricity ✓" : "Does Not Conduct Electricity ✗"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .fill(accentColor.opacity(0.15))
                        .frame(width: 36, height: 36)
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(accentColor)
                }
                Text(title)
                    .font(.subheadline.bold())
                    .foregroundStyle(accentColor)
            }

            Text(explanation)
                .font(.subheadline)
                .foregroundStyle(Color.secondary)
                .fixedSize(horizontal: false, vertical: true)

            // Visual free-electron diagram
            if conducts {
                FreeElectronDiagram()
            } else {
                LockedElectronDiagram()
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.secondarySystemGroupedBackground))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(accentColor.opacity(0.35), lineWidth: 1.5)
                )
        )
    }
}

// MARK: - Inline electron diagrams

struct FreeElectronDiagram: View {
    @State private var offset: CGFloat = -80

    var body: some View {
        ZStack {
            // Track
            RoundedRectangle(cornerRadius: 4)
                .fill(Color(red: 0.1, green: 0.85, blue: 0.35).opacity(0.12))
                .frame(height: 28)

            // Flowing electrons
            HStack(spacing: 0) {
                ForEach(0..<5, id: \.self) { i in
                    Circle()
                        .fill(Color(red: 0.2, green: 0.95, blue: 0.45))
                        .frame(width: 10, height: 10)
                        .shadow(color: Color(red: 0.2, green: 0.95, blue: 0.45).opacity(0.8), radius: 4)
                        .offset(x: offset + CGFloat(i) * 36)
                        .opacity(electronOpacity(index: i))
                }
            }
            .clipped()

            HStack {
                Image(systemName: "minus")
                    .font(.caption2.bold())
                    .foregroundStyle(Color(red: 0.1, green: 0.85, blue: 0.35))
                    .padding(.leading, 6)
                Spacer()
                Image(systemName: "plus")
                    .font(.caption2.bold())
                    .foregroundStyle(Color(red: 1.0, green: 0.5, blue: 0.2))
                    .padding(.trailing, 6)
            }
        }
        .frame(height: 28)
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .onAppear {
            withAnimation(.linear(duration: 1.4).repeatForever(autoreverses: false)) {
                offset = 80
            }
        }
    }

    private func electronOpacity(index: Int) -> Double {
        let pos = offset + CGFloat(index) * 36
        let edge: CGFloat = 60
        if pos < -edge || pos > edge { return 0 }
        return 1.0
    }
}

struct LockedElectronDiagram: View {
    @State private var shake: CGFloat = 0

    var body: some View {
        HStack(spacing: 12) {
            ForEach(0..<4, id: \.self) { i in
                ZStack {
                    Circle()
                        .fill(Color(.systemGray5))
                        .frame(width: 24, height: 24)
                    Image(systemName: "lock.fill")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(Color(red: 1.0, green: 0.3, blue: 0.25))
                }
                .offset(x: shake * (i % 2 == 0 ? 1 : -1))
            }

            Image(systemName: "arrow.right")
                .foregroundStyle(Color(.systemGray3))
                .font(.caption)

            ZStack {
                Circle()
                    .fill(Color(red: 1.0, green: 0.3, blue: 0.25).opacity(0.15))
                    .frame(width: 24, height: 24)
                Image(systemName: "xmark")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Color(red: 1.0, green: 0.3, blue: 0.25))
            }

            Text("No flow")
                .font(.caption2.bold())
                .foregroundStyle(Color(red: 1.0, green: 0.3, blue: 0.25))
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(red: 1.0, green: 0.3, blue: 0.25).opacity(0.07))
        )
        .onAppear {
            withAnimation(.easeInOut(duration: 0.12).repeatCount(6, autoreverses: true).delay(0.5)) {
                shake = 3
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                withAnimation(.easeInOut(duration: 0.12).repeatCount(6, autoreverses: true)) {
                    shake = 3
                }
            }
        }
    }
}

// MARK: - Detail Section

struct DetailSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Theme.secondarySystemBackground)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

