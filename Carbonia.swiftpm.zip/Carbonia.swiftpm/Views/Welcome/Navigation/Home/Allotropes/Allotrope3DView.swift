import SwiftUI
import SceneKit

struct Allotrope3DView: UIViewRepresentable {
    let allotropeName: String
    @Binding var scale: CGFloat
    var conductivityMode: Bool = false
    var conductsElectricity: Bool = false

    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        let scene = AllotropeSceneFactory.scene(for: allotropeName)
        view.scene = scene
        view.allowsCameraControl = false
        view.autoenablesDefaultLighting = false
        view.backgroundColor = .clear
        view.isOpaque = false
        view.preferredFramesPerSecond = 60

        // Fixed camera — always centred on origin
        let cameraNode = SCNNode()
        cameraNode.name = "fixedCamera"
        cameraNode.camera = SCNCamera()
        cameraNode.camera!.fieldOfView = 60
        cameraNode.position = SCNVector3(0, 0, 8)
        scene.rootNode.addChildNode(cameraNode)
        view.pointOfView = cameraNode

        // Wrap all geometry in a single pivot node so we rotate that, not the camera
        let pivot = SCNNode()
        pivot.name = "pivot"
        // Re-parent existing children (except lights and camera) into pivot
        for child in scene.rootNode.childNodes {
            guard child.name != "fixedCamera",
                  child.light == nil else { continue }
            child.removeFromParentNode()
            pivot.addChildNode(child)
        }
        scene.rootNode.addChildNode(pivot)

        // Drag gesture — rotate pivot
        let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        view.addGestureRecognizer(pan)

        // Pinch gesture — zoom camera Z
        let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        view.addGestureRecognizer(pinch)

        context.coordinator.scnView = view

        return view
    }

    func updateUIView(_ uiView: SCNView, context: Context) {
        // Update camera Z from scale binding
        if let cam = uiView.scene?.rootNode.childNode(withName: "fixedCamera", recursively: false) {
            cam.position = SCNVector3(0, 0, Float(8 / scale))
        }

        if conductivityMode {
            AllotropeSceneFactory.applyConductivityEffect(
                to: uiView.scene,
                conducts: conductsElectricity,
                allotropeName: allotropeName
            )
        } else {
            AllotropeSceneFactory.removeConductivityEffect(from: uiView.scene)
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    @MainActor
    class Coordinator: NSObject {
        weak var scnView: SCNView?
        private var lastTranslation: CGPoint = .zero

        @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
            guard let view = scnView,
                  let pivot = view.scene?.rootNode.childNode(withName: "pivot", recursively: false)
            else { return }

            let translation = gesture.translation(in: view)

            if gesture.state == .began {
                lastTranslation = .zero
            }

            let delta = CGPoint(
                x: translation.x - lastTranslation.x,
                y: translation.y - lastTranslation.y
            )
            lastTranslation = translation

            let sensitivity: Float = 0.005
            let yaw   = Float(delta.x) * sensitivity   // rotate around Y
            let pitch = Float(delta.y) * sensitivity   // rotate around X

            // Apply incremental rotation in world space
            let currentEuler = pivot.eulerAngles
            pivot.eulerAngles = SCNVector3(
                currentEuler.x + pitch,
                currentEuler.y + yaw,
                currentEuler.z
            )
        }

        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            guard let view = scnView,
                  let cam = view.scene?.rootNode.childNode(withName: "fixedCamera", recursively: false)
            else { return }

            if gesture.state == .changed {
                let newZ = cam.position.z / Float(gesture.scale)
                cam.position.z = max(3, min(20, newZ))
                gesture.scale = 1
            }
        }
    }
}

