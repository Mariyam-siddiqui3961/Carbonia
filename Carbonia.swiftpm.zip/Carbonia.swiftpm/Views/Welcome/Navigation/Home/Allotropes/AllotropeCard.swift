// AllotropeCard.swift — kept for future use; currently unused.
import SwiftUI
