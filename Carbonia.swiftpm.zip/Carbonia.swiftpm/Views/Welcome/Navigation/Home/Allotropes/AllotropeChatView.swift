import SwiftUI

@available(iOS 17.0, *)
struct AllotropeChatView: View {
    let allotrope: Allotrope
    @Environment(\.dismiss) private var dismiss

    @State private var messages: [ChatMessage] = []
    @State private var inputText = ""
    @State private var isLoading = false
    @State private var aiService = ChemistryAIService()

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                messageList
                if messages.count <= 1 && !isLoading {
                    hintQuestions
                }
                inputBar
            }
            .navigationTitle("\(allotrope.name) Assistant")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear {
                guard messages.isEmpty else { return }
                Task { await startConversation() }
            }
        }
    }

    private var hintQuestions: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(questionsFor(allotrope.name), id: \.self) { q in
                    Button {
                        inputText = q
                        Task { await sendMessage() }
                    } label: {
                        Text(q)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(Color.blue)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.blue.opacity(0.1), in: Capsule())
                            .overlay(Capsule().stroke(Color.blue.opacity(0.3), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .background(.thinMaterial)
    }

    private func questionsFor(_ name: String) -> [String] {
        switch name.lowercased() {
        case "diamond":
            return [
                "Why is diamond the hardest natural substance?",
                "Why doesn't diamond conduct electricity?",
                "How is diamond formed in nature?"
            ]
        case "graphite":
            return [
                "Why does graphite conduct electricity?",
                "Why is graphite soft and slippery?",
                "How are graphite's layers held together?"
            ]
        case "fullerene":
            return [
                "What makes C₆₀ a semiconductor?",
                "How was fullerene discovered?",
                "What are fullerene's uses in medicine?"
            ]
        default:
            return [
                "Why is amorphous carbon a poor conductor?",
                "What makes activated carbon a good filter?",
                "How is amorphous carbon different from graphite?"
            ]
        }
    }

    // MARK: - Sub-views

    private var messageList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(messages) { message in
                        ChatBubble(message: message)
                            .id(message.id)
                    }
                    if isLoading {
                        LoadingBubble().id("loading")
                    }
                }
                .padding()
            }
            .scrollIndicators(.hidden)
            .onChange(of: messages.count) {
                if let lastId = messages.last?.id {
                    withAnimation { proxy.scrollTo(lastId, anchor: .bottom) }
                }
            }
        }
    }

    private var inputBar: some View {
        HStack(spacing: 12) {
            TextField("Ask about \(allotrope.name)...", text: $inputText)
                .padding(12)
                .background(Color(.systemGray6), in: Capsule())
                .disabled(isLoading)
                .submitLabel(.send)
                .onSubmit { Task { await sendMessage() } }
                .accessibilityLabel("Message input field")

            Button {
                Task { await sendMessage() }
            } label: {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(inputText.isEmpty || isLoading ? .secondary : Color.blue)
            }
            .disabled(inputText.isEmpty || isLoading)
            .accessibilityLabel("Send message")
        }
        .padding()
        .background(.thinMaterial)
    }

    // MARK: - Logic

    private func startConversation() async {
        isLoading = true
        let response = await aiService.explainAllotrope(
            name: allotrope.name,
            structure: allotrope.structure,
            properties: allotrope.properties
        )
        messages.append(ChatMessage(text: response, isUser: false))
        isLoading = false
    }

    private func sendMessage() async {
        let text = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        inputText = ""
        messages.append(ChatMessage(text: text, isUser: true))
        isLoading = true
        let response = await aiService.chat(input: text)
        messages.append(ChatMessage(text: response, isUser: false))
        isLoading = false
    }
}
