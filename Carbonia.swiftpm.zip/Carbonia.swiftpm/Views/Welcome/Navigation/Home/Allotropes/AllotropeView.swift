import SwiftUI

struct Allotrope: Identifiable {
    var id: String { name }
    let name: String
    let imageName: String
    let formula: Text
    let structure: String
    let properties: [String]
    let uses: [String]
    let cardColor: Color
    let useDarkText: Bool
    let conductsElectricity: Bool
    let conductivityExplanation: String
}

@available(iOS 17.0, *)
struct AllotropesView: View {

    private let allotropes: [Allotrope] = [
        Allotrope(
            name: "Diamond",
            imageName: "diamond_3d",
            formula: Text("C"),
            structure: "Tetrahedral crystal lattice",
            properties: ["Hardest natural substance", "Electrical insulator", "High refractive index"],
            uses: ["Jewelry", "Cutting tools", "Abrasives"],
            cardColor: Color(red: 0.722, green: 0.776, blue: 0.859),
            useDarkText: true,
            conductsElectricity: false,
            conductivityExplanation: "All 4 valence electrons of each carbon atom are locked in strong covalent bonds, leaving no free electrons to carry charge."
        ),
        Allotrope(
            name: "Graphite",
            imageName: "graphite_3d",
            formula: Text("C"),
            structure: "Layered hexagonal sheets",
            properties: ["Soft and slippery", "Conducts electricity", "High melting point"],
            uses: ["Pencils", "Lubricants", "Batteries"],
            cardColor: Color(red: 0.227, green: 0.227, blue: 0.235),
            useDarkText: false,
            conductsElectricity: true,
            conductivityExplanation: "Each carbon uses only 3 of its 4 valence electrons for bonding. The 4th electron is delocalised across the hexagonal layers, forming a sea of mobile electrons."
        ),
        Allotrope(
            name: "Fullerene",
            imageName: "fullerene_3d",
            formula: Text("C\(Text("60").font(.caption).baselineOffset(-4))"),
            structure: "Spherical cage-like molecules (20 hexagons & 12 pentagons)",
            properties: ["Lightweight", "Strong", "Conductive"],
            uses: ["Nanotechnology", "Medicine", "Lubricants"],
            cardColor: Color(red: 0.227, green: 0.357, blue: 0.627),
            useDarkText: false,
            conductsElectricity: true,
            conductivityExplanation: "Delocalised π-electrons spread across the conjugated carbon cage allow charge to flow, making C₆₀ a semiconductor that can be doped into a superconductor."
        ),
        Allotrope(
            name: "Amorphous Carbon",
            imageName: "amorphous_3d",
            formula: Text("C"),
            structure: "Irregular arrangement of atoms",
            properties: ["Porous", "Absorbs impurities", "Variable hardness"],
            uses: ["Charcoal", "Filters", "Fuel"],
            cardColor: Color(red: 0.173, green: 0.173, blue: 0.180),
            useDarkText: false,
            conductsElectricity: false,
            conductivityExplanation: "Without a regular crystalline structure, electrons cannot delocalise freely. The disordered bonds trap charge carriers, making it a poor conductor."
        )
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ForEach(allotropes) { allotrope in
                    NavigationLink(destination: AllotropeDetailView(allotrope: allotrope)) {
                        AllotropeListCard(allotrope: allotrope)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(allotrope.name)
                    .accessibilityHint("View details and use AI assistant")
                }
            }
            .padding(20)
        }
        .scrollIndicators(.hidden)
        .background(Theme.groupedBackground)
        .navigationTitle("Allotropes")
        .navigationBarTitleDisplayMode(.large)
    }
}

struct AllotropeListCard: View {
    let allotrope: Allotrope
    private let height: CGFloat = 170

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Image(allotrope.imageName)
                .resizable()
                .scaledToFill()
                .frame(maxWidth: .infinity)
                .frame(height: height)
                .clipped()

            LinearGradient(
                colors: [Color.black.opacity(0.65), .clear],
                startPoint: .bottom,
                endPoint: .center
            )

            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(allotrope.name)
                        .font(.title3.bold())
                        .foregroundStyle(Color.white)

                    HStack(spacing: 4) {
                        Text("Formula:")
                            .font(.caption)
                            .foregroundStyle(Color.white.opacity(0.8))
                        allotrope.formula
                            .font(.caption.bold())
                            .foregroundStyle(Color.white)
                    }
                }
                Spacer()
            }
            .padding()
        }
        .frame(height: height)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
    }
}
