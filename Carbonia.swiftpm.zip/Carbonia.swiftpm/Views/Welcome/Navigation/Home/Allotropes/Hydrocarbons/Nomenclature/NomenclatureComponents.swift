import SwiftUI

struct NomenclatureHeaderSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("IUPAC Naming")
                .font(.title3.bold())
            Text("Learn how to systematically name organic compounds.")
                .font(.subheadline)
                .foregroundStyle(Color.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct NomenclatureWalkthroughSection: View {
    @Binding var selectedMolecule: NomenclatureMoleculeType
    @Binding var currentStep: Int
    let steps: [String]

    var body: some View {
        VStack(spacing: 20) {
            Picker("Molecule", selection: $selectedMolecule) {
                ForEach(NomenclatureMoleculeType.allCases) { type in
                    Text(type.rawValue).tag(type)
                }
            }
            .pickerStyle(.segmented)
            .accessibilityLabel("Molecule type selector")
            .onChange(of: selectedMolecule) {
                withAnimation { currentStep = 0 }
            }

            NomenclatureInteractiveStructure(moleculeType: selectedMolecule, step: currentStep)
                .id("\(selectedMolecule.rawValue)-\(currentStep)")
                .transition(.opacity)
                .accessibilityLabel("Interactive structure diagram, step \(currentStep + 1) of \(steps.count)")

            NomenclatureWalkthroughControls(
                currentStep: $currentStep,
                totalSteps: steps.count,
                stepDescription: steps[currentStep]
            )
        }
        .padding()
        .background(Theme.secondarySystemBackground)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 5)
    }
}

struct NomenclatureWalkthroughControls: View {
    @Binding var currentStep: Int
    let totalSteps: Int
    let stepDescription: String

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(stepDescription)
                .font(.body.weight(.medium))
                .multilineTextAlignment(.leading)
                .frame(minHeight: 60)
                .animation(.default, value: currentStep)
                .accessibilityLabel(stepDescription)

            HStack {
                Button {
                    withAnimation { if currentStep > 0 { currentStep -= 1 } }
                } label: {
                    Label("Back", systemImage: "chevron.left")
                        .fontWeight(.semibold)
                }
                .buttonStyle(.bordered)
                .disabled(currentStep == 0)
                .accessibilityLabel("Previous step")

                Spacer()

                HStack(spacing: 8) {
                    ForEach(0..<totalSteps, id: \.self) { i in
                        Circle()
                            .fill(i == currentStep ? Theme.accent : Color.secondary.opacity(0.3))
                            .frame(width: 7, height: 7)
                            .animation(.spring, value: currentStep)
                    }
                }
                .accessibilityHidden(true)

                Spacer()

                Button {
                    withAnimation {
                        if currentStep < totalSteps - 1 { currentStep += 1 }
                        else { currentStep = 0 }
                    }
                } label: {
                    if currentStep == totalSteps - 1 {
                        Label("Reset", systemImage: "arrow.counterclockwise")
                            .fontWeight(.bold)
                    } else {
                        HStack(spacing: 4) {
                            Text("Next").fontWeight(.bold)
                            Image(systemName: "chevron.right").font(.caption.bold())
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
                .accessibilityLabel(currentStep == totalSteps - 1 ? "Restart walkthrough" : "Next step")
            }
        }
        .padding()
        .background(Color(.systemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - Rules Section (collapsible)

struct NomenclatureRulesSection: View {
    @State private var isExpanded = false

    var body: some View {
        VStack(spacing: 0) {
            // Header button
            Button {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                    isExpanded.toggle()
                }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "list.bullet.clipboard")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.blue)
                    Text("Naming Rules")
                        .font(.headline)
                        .foregroundColor(Color(uiColor: .label))
                    Spacer()
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Naming Rules")
            .accessibilityHint(isExpanded ? "Tap to collapse" : "Tap to expand")

            // Expandable content
            if isExpanded {
                VStack(spacing: 12) {
                    Divider().padding(.horizontal, 16)

                    VStack(spacing: 12) {
                        RuleCard(
                            number: 1,
                            title: "Find the Longest Chain",
                            description: "Identify the longest continuous chain of carbon atoms. This determines the parent name.",
                            icon: "ruler.fill",
                            color: .blue
                        )
                        RuleCard(
                            number: 2,
                            title: "Number the Chain",
                            description: "Number starting from the end closest to a substituent or bond.",
                            icon: "list.number",
                            color: .green
                        )
                        RuleCard(
                            number: 3,
                            title: "Identify Substituents",
                            description: "Name any branches (e.g., methyl). Use prefixes for multiples.",
                            icon: "arrow.triangle.branch",
                            color: .orange
                        )
                        RuleCard(
                            number: 4,
                            title: "Assemble the Name",
                            description: "Combine parts alphabetically. Use hyphens and commas correctly.",
                            icon: "textformat.abc",
                            color: .purple
                        )
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .background(Theme.secondarySystemBackground)
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 5)
    }
}

// MARK: - AI Button

struct NomenclatureAIAssistantButton: View {
    @Binding var showAIChat: Bool

    var body: some View {
        Button {
            showAIChat = true
        } label: {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 1.0,  green: 0.72, blue: 0.3),
                                Color(red: 0.95, green: 0.38, blue: 0.55),
                                Color(red: 0.35, green: 0.62, blue: 1.0)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 60, height: 60)
                    .shadow(color: Color(red: 0.95, green: 0.38, blue: 0.55).opacity(0.45),
                            radius: 10, x: 0, y: 4)
                Image(systemName: "atom")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(Color.white)
            }
        }
        .accessibilityLabel("Open AI Nomenclature Assistant")
    }
}
