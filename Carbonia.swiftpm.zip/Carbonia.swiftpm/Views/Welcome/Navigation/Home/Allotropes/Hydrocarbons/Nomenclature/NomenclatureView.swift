import SwiftUI

@available(iOS 17.0, *)
struct NomenclatureView: View {
    @State private var currentStep: Int = 0
    @State private var selectedMolecule: NomenclatureMoleculeType = .alkane
    @State private var showAIChat = false

    private var steps: [String] {
        switch selectedMolecule {
        case .alkane:
            return [
                "2-methylbutane",
                "Step 1: Longest continuous chain has 4 carbons → Butane.",
                "Step 2: Number from left or right? Closest to branch is from left (position 2).",
                "Step 3: Branch at position 2 is a 'methyl' group.",
                "Step 4: Combine: 2-methylbutane."
            ]
        case .alkene:
            return [
                "But-1-ene",
                "Step 1: Parent chain contains the double bond and has 4 carbons → Butene.",
                "Step 2: Number from end closest to double bond (left to right).",
                "Step 3: Double bond starts at carbon 1.",
                "Step 4: Name becomes But-1-ene (or 1-butene)."
            ]
        case .alkyne:
            return [
                "Propyne",
                "Step 1: Parent chain contains triple bond and has 3 carbons → Propyne.",
                "Step 2: Number from end closest to triple bond (left to right).",
                "Step 3: Triple bond starts at carbon 1.",
                "Step 4: Full name is Propyne (position 1 is implied here)."
            ]
        }
    }

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ScrollView {
                VStack(spacing: 32) {
                    NomenclatureHeaderSection()
                    NomenclatureWalkthroughSection(
                        selectedMolecule: $selectedMolecule,
                        currentStep: $currentStep,
                        steps: steps
                    )
                    NomenclatureRulesSection()
                }
                .padding(24)
                .padding(.bottom, 90)
            }
            .scrollIndicators(.hidden)
            .background(Theme.groupedBackground)

            NomenclatureAIAssistantButton(showAIChat: $showAIChat)
                .padding(.bottom, 28)
                .padding(.trailing, 28)
        }
        .navigationTitle("Nomenclature")
        .navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $showAIChat) {
            NomenclatureChatView()
        }
    }
}

@available(iOS 17.0, *)
struct NomenclatureView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack { NomenclatureView() }
    }
}
