import SwiftUI

struct HydrocarbonTypeSection: View {
    @Binding var selectedType: HydrocarbonType

    var body: some View {
        Section(header: Text("Hydrocarbon Type")) {
            Picker("Type", selection: $selectedType) {
                ForEach(HydrocarbonType.allCases) { type in
                    Text(type.rawValue).tag(type)
                }
            }
            .pickerStyle(.segmented)
            .accessibilityLabel("Hydrocarbon type selector")
        }
    }
}

struct HydrocarbonCarbonSection: View {
    @Binding var carbonCount: Int
    let carbonPrefix: String
    var minCarbons: Int = 1

    var body: some View {
        Section(header: Text("Carbon Atoms")) {
            Stepper(value: $carbonCount, in: minCarbons...10) {
                HStack {
                    Text("\(carbonCount) Carbon\(carbonCount > 1 ? "s" : "")")
                    Spacer()
                    Text("Prefix:")
                        .foregroundStyle(Color.secondary)
                        .font(.subheadline)
                    Text(carbonPrefix)
                        .foregroundStyle(Color.blue)
                        .font(.subheadline.bold())
                }
            }
            .accessibilityLabel("Carbon count stepper, currently \(carbonCount)")
        }
    }
}

struct HydrocarbonMoleculeSection: View {
    let moleculeName: String
    let formula: String
    let structureString: String
    let selectedType: HydrocarbonType
    let carbonCount: Int

    var body: some View {
        Section(header: Text("Molecule")) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(moleculeName.capitalized)
                        .font(.headline)
                    Text(formula)
                        .font(.subheadline)
                        .foregroundStyle(Color.secondary)
                }
                Spacer()
                // Bond-type badge
                Text(bondBadge)
                    .font(.caption.bold())
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(badgeColor, in: Capsule())
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("\(moleculeName.capitalized), formula \(formula)")

            ScrollView(.horizontal, showsIndicators: false) {
                HydrocarbonStructureView(type: selectedType, carbonCount: carbonCount)
                    .padding()
            }
            .frame(height: 300)
            .accessibilityLabel("Interactive structural diagram for \(moleculeName)")
        }
    }

    private var bondBadge: String {
        switch selectedType {
        case .alkane: return "C–C"
        case .alkene: return "C=C"
        case .alkyne: return "C≡C"
        }
    }

    private var badgeColor: Color {
        switch selectedType {
        case .alkane: return .gray
        case .alkene: return .blue
        case .alkyne: return .purple
        }
    }
}

struct HydrocarbonPropertiesSection: View {
    let generalFormulaText: Text
    let bondType: String
    let suffix: String

    var body: some View {
        Section(header: Text("Properties")) {
            HStack {
                Text("General Formula")
                    .foregroundStyle(Color.secondary)
                Spacer()
                generalFormulaText.fontWeight(.semibold)
            }
            HStack {
                Text("Bond Type")
                    .foregroundStyle(Color.secondary)
                Spacer()
                Text(bondType).fontWeight(.semibold)
            }
            HStack {
                Text("Suffix")
                    .foregroundStyle(Color.secondary)
                Spacer()
                Text(suffix).fontWeight(.semibold)
            }
        }
    }
}

struct HydrocarbonAISection: View {
    let showAISuggestion: Bool
    let isLoadingAI: Bool
    let aiReaction: ReactionSuggestion?
    let onLoadReaction: () -> Void

    var body: some View {
        Section(header: Label("AI Reaction Suggestion", systemImage: "sparkles")) {
            if showAISuggestion {
                aiSuggestionContent
            } else {
                Button {
                    onLoadReaction()
                } label: {
                    Label("Suggest a Reaction", systemImage: "sparkles")
                        .frame(maxWidth: .infinity)
                }
            }
        }
    }

    @ViewBuilder
    private var aiSuggestionContent: some View {
        if isLoadingAI {
            HStack(spacing: 10) {
                ProgressView().scaleEffect(0.8)
                Text("Thinking…")
                    .font(.subheadline)
                    .foregroundStyle(Color.secondary)
            }
        } else if let reaction = aiReaction {
            VStack(alignment: .leading, spacing: 12) {
                Text(reaction.type)
                    .font(.caption.bold())
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.blue, in: Capsule())

                Text(reaction.equation)
                    .font(.system(.body, design: .monospaced))
                    .foregroundStyle(Color.blue)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 8))

                Text(reaction.explanation)
                    .font(.subheadline)
                    .foregroundStyle(Color.secondary)
            }

            Button("Get New Suggestion") {
                onLoadReaction()
            }
            .font(.caption)
        }
    }
}
