import SwiftUI

enum NomenclatureMoleculeType: String, CaseIterable, Identifiable {
    case alkane = "Alkane"
    case alkene = "Alkene"
    case alkyne = "Alkyne"
    
    var id: String { rawValue }
}

struct NomenclatureInteractiveStructure: View {
    let moleculeType: NomenclatureMoleculeType
    let step: Int
    
    private let carbonSize: CGFloat = 46
    private let bondLength: CGFloat = 36
    private let bondThickness: CGFloat = 6
    
    var body: some View {
        ZStack {
            switch moleculeType {
            case .alkane:
                AlkaneStructureView(step: step, carbonSize: carbonSize, bondLength: bondLength, bondThickness: bondThickness)
            case .alkene:
                AlkeneStructureView(step: step, carbonSize: carbonSize, bondLength: bondLength, bondThickness: bondThickness)
            case .alkyne:
                AlkyneStructureView(step: step, carbonSize: carbonSize, bondLength: bondLength, bondThickness: bondThickness)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 180)
        .background(Color.primary.opacity(0.03))
        .cornerRadius(16)
    }
}

// MARK: - Sub-views

// MARK: - Sub-views

struct AlkaneStructureView: View {
    let step: Int
    let carbonSize: CGFloat
    let bondLength: CGFloat
    let bondThickness: CGFloat
    
    var body: some View {
        VStack(spacing: 0) {
            // Methyl Branch row
            HStack(spacing: 0) {
                // Leading spacer to align with C2
                // Each carbon group is carbonSize + bondLength
                // But the last group is just carbonSize
                // C1 is at index 0. C2 is at index 1.
                // Distance to center of C2 = (carbonSize + bondLength)
                Spacer().frame(width: carbonSize + bondLength)
                
                VStack(spacing: 0) {
                    NomenclatureAtomView(
                        color: branchColor,
                        size: carbonSize,
                        label: "C",
                        indexLabel: "Methyl",
                        showIndex: step >= 3
                    )
                    NomenclatureBondView(
                        color: branchColor,
                        width: bondThickness,
                        height: bondLength,
                        orientation: .vertical
                    )
                }
                
                // Trailing spacer to balance the width
                // Total chain width = 4 carbons + 3 bonds = 4*46 + 3*36 = 184 + 108 = 292
                // Leading spacer + branch atom center = (46 + 36) + 23 = 105
                // Remaining width = 292 - 105 = 187
                Spacer().frame(width: (carbonSize + bondLength) * 2)
            }
            .frame(width: (carbonSize * 4) + (bondLength * 3))
            
            // Parent Chain: Butane
            HStack(spacing: 0) {
                ForEach(1...4, id: \.self) { i in
                    ZStack {
                        NomenclatureAtomView(
                            color: chainColor,
                            size: carbonSize,
                            label: "C",
                            indexLabel: "\(i)",
                            showIndex: step >= 2
                        )
                        
                        if i < 4 {
                            NomenclatureBondView(
                                color: chainColor,
                                width: bondLength,
                                height: bondThickness,
                                orientation: .horizontal
                            )
                            .offset(x: carbonSize/2 + bondLength/2)
                        }
                    }
                    if i < 4 { Spacer().frame(width: bondLength) }
                }
            }
        }
    }
    
    private var chainColor: Color {
        step >= 1 ? .blue : .gray
    }
    
    private var branchColor: Color {
        step >= 3 ? .orange : (step >= 1 ? .blue : Color.gray)
    }
}

struct AlkeneStructureView: View {
    let step: Int
    let carbonSize: CGFloat
    let bondLength: CGFloat
    let bondThickness: CGFloat
    
    var body: some View {
        VStack(spacing: 0) {
            // Spacer to match Alkane branch height
            Color.clear.frame(height: carbonSize + bondLength)
            
            HStack(spacing: 0) {
                ForEach(1...4, id: \.self) { i in
                    ZStack {
                        NomenclatureAtomView(
                            color: chainColor,
                            size: carbonSize,
                            label: "C",
                            indexLabel: "\(i)",
                            showIndex: step >= 2
                        )
                        
                        if i < 4 {
                            let isDouble = i == 1
                            let bondColor = (isDouble && step >= 3) ? Color.orange : chainColor
                            
                            MultiBondView(
                                bondCount: isDouble ? 2 : 1,
                                color: bondColor,
                                length: bondLength,
                                thickness: bondThickness,
                                orientation: .horizontal
                            )
                            .overlay(
                                Text("Double Bond")
                                    .font(.caption2)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.orange)
                                    .offset(y: -30)
                                    .opacity(isDouble && step >= 3 ? 1 : 0)
                            )
                            .offset(x: carbonSize/2 + bondLength/2)
                        }
                    }
                    if i < 4 { Spacer().frame(width: bondLength) }
                }
            }
        }
    }
    
    private var chainColor: Color {
        step >= 1 ? .blue : .gray
    }
}

struct AlkyneStructureView: View {
    let step: Int
    let carbonSize: CGFloat
    let bondLength: CGFloat
    let bondThickness: CGFloat
    
    var body: some View {
        VStack(spacing: 0) {
            // Spacer to match Alkane branch height
            Color.clear.frame(height: carbonSize + bondLength)
            
            HStack(spacing: 0) {
                ForEach(1...3, id: \.self) { i in
                    ZStack {
                        NomenclatureAtomView(
                            color: chainColor,
                            size: carbonSize,
                            label: "C",
                            indexLabel: "\(i)",
                            showIndex: step >= 2
                        )
                        
                        if i < 3 {
                            let isTriple = i == 1
                            let bondColor = (isTriple && step >= 3) ? Color.orange : chainColor
                            
                            MultiBondView(
                                bondCount: isTriple ? 3 : 1,
                                color: bondColor,
                                length: bondLength,
                                thickness: bondThickness,
                                orientation: .horizontal
                            )
                            .overlay(
                                Text("Triple Bond")
                                    .font(.caption2)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.orange)
                                    .offset(y: -30)
                                    .opacity(isTriple && step >= 3 ? 1 : 0)
                            )
                            .offset(x: carbonSize/2 + bondLength/2)
                        }
                    }
                    if i < 3 { Spacer().frame(width: bondLength) }
                }
            }
        }
    }
    
    private var chainColor: Color {
        step >= 1 ? .blue : .gray
    }
}

// MARK: - Components

struct NomenclatureAtomView: View {
    let color: Color
    let size: CGFloat
    let label: String
    let indexLabel: String
    let showIndex: Bool
    
    var body: some View {
        AtomSphereView(color: color, size: size, label: label)
            .overlay(
                indexBadge
                    .offset(y: indexLabel.count > 2 ? -30 : 35)
                    .opacity(showIndex ? 1 : 0)
            )
    }
    
    @ViewBuilder
    private var indexBadge: some View {
        if indexLabel.count > 2 {
            // Text label (e.g. "Methyl")
            Text(indexLabel)
                .font(.caption2)
                .fontWeight(.bold)
                .foregroundColor(color)
        } else {
            // Number badge
            Text(indexLabel)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .padding(4)
                .background(Circle().fill(Color.green))
        }
    }
}

struct NomenclatureBondView: View {
    let color: Color
    let width: CGFloat
    let height: CGFloat
    let orientation: BondCylinderView.Orientation
    
    var body: some View {
        BondCylinderView(color: color, width: width, height: height, orientation: orientation)
    }
}
