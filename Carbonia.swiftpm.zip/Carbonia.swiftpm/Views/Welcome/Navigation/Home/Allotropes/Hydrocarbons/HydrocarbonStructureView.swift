import SwiftUI

struct HydrocarbonStructureView: View {
    let type: HydrocarbonType
    let carbonCount: Int

    private let carbonSize: CGFloat = 50
    private let hydrogenSize: CGFloat = 30
    private let bondLength: CGFloat = 40
    private let bondThickness: CGFloat = 8

    var body: some View {
        HStack(spacing: -5) {
            ForEach(0..<carbonCount, id: \.self) { index in
                if index > 0 {
                    BondView(type: type, index: index, bondLength: bondLength, bondThickness: bondThickness)
                        .zIndex(0)
                }
                CarbonGroupView(
                    index: index,
                    carbonCount: carbonCount,
                    type: type,
                    carbonSize: carbonSize,
                    hydrogenSize: hydrogenSize,
                    bondLength: bondLength,
                    bondThickness: bondThickness
                )
                .zIndex(1)
            }
        }
        .padding(50)
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .shadow(radius: 4)
    }
}

// MARK: - Color constants matching CovalentBondingSection
private enum MoleculeColors {
    // C atom — purple radial gradient (matches nucleus / C in covalent view)
    static let carbonLight = Color(red: 0.55, green: 0.28, blue: 0.95)
    static let carbonDark  = Color(red: 0.20, green: 0.10, blue: 0.65)
    // H atom — blue radial gradient (matches K-shell / H in covalent view)
    static let hydrogenLight = Color(red: 0.42, green: 0.72, blue: 1.0)
    static let hydrogenDark  = Color(red: 0.12, green: 0.38, blue: 0.85)
    // Bond lines
    static let bond = Color(uiColor: .systemGray3)
}

// MARK: - Sub-views

struct CarbonGroupView: View {
    let index: Int
    let carbonCount: Int
    let type: HydrocarbonType
    let carbonSize: CGFloat
    let hydrogenSize: CGFloat
    let bondLength: CGFloat
    let bondThickness: CGFloat

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                if hasTopHydrogen {
                    HydrogenAtomView(size: hydrogenSize)
                    VerticalBondView(thickness: bondThickness, length: bondLength / 2)
                } else {
                    Color.clear.frame(width: hydrogenSize, height: hydrogenSize + bondLength / 2)
                }

                Color.clear.frame(width: carbonSize, height: carbonSize)

                if hasBottomHydrogen {
                    VerticalBondView(thickness: bondThickness, length: bondLength / 2)
                    HydrogenAtomView(size: hydrogenSize)
                } else {
                    Color.clear.frame(width: hydrogenSize, height: hydrogenSize + bondLength / 2)
                }
            }

            // C atom — purple gradient
            ZStack {
                Circle()
                    .fill(RadialGradient(
                        colors: [MoleculeColors.carbonLight, MoleculeColors.carbonDark],
                        center: .center, startRadius: 0, endRadius: carbonSize / 2))
                    .frame(width: carbonSize, height: carbonSize)
                    .shadow(color: MoleculeColors.carbonLight.opacity(0.5), radius: 8, x: 0, y: 4)
                Text("C")
                    .font(.system(size: carbonSize * 0.36, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            }

            if index == 0 && hasLeftHydrogen {
                HStack(spacing: 0) {
                    HydrogenAtomView(size: hydrogenSize)
                    HorizontalBondView(width: bondLength / 2, thickness: bondThickness)
                }
                .offset(x: -(carbonSize / 2 + bondLength / 2 + hydrogenSize / 2))
            }

            if index == carbonCount - 1 {
                HStack(spacing: 0) {
                    HorizontalBondView(width: bondLength / 2, thickness: bondThickness)
                    HydrogenAtomView(size: hydrogenSize)
                }
                .offset(x: (carbonSize / 2 + bondLength / 2 + hydrogenSize / 2))
            }
        }
        .frame(width: carbonSize + (index == 0 ? 30 : 0) + (index == carbonCount - 1 ? 30 : 0))
    }

    private var hasTopHydrogen: Bool {
        switch type {
        case .alkane: return true
        case .alkene: return true
        case .alkyne: return index >= 2
        }
    }

    private var hasBottomHydrogen: Bool {
        switch type {
        case .alkane: return true
        case .alkene: return index != 1
        case .alkyne: return index >= 2
        }
    }

    private var hasLeftHydrogen: Bool {
        switch type {
        case .alkane: return true
        case .alkene: return false
        case .alkyne: return true
        }
    }
}

struct BondView: View {
    let type: HydrocarbonType
    let index: Int
    let bondLength: CGFloat
    let bondThickness: CGFloat

    var body: some View {
        if index == 1 {
            switch type {
            case .alkene: DoubleBondView(length: bondLength, thickness: bondThickness)
            case .alkyne: TripleBondView(length: bondLength, thickness: bondThickness)
            case .alkane: SingleBondView(length: bondLength, thickness: bondThickness)
            }
        } else {
            SingleBondView(length: bondLength, thickness: bondThickness)
        }
    }
}

struct HydrogenAtomView: View {
    let size: CGFloat
    var body: some View {
        ZStack {
            Circle()
                .fill(RadialGradient(
                    colors: [MoleculeColors.hydrogenLight, MoleculeColors.hydrogenDark],
                    center: .center, startRadius: 0, endRadius: size / 2))
                .frame(width: size, height: size)
                .shadow(color: MoleculeColors.hydrogenLight.opacity(0.45), radius: 5, x: 0, y: 2)
            Text("H")
                .font(.system(size: size * 0.38, weight: .bold, design: .rounded))
                .foregroundColor(.white)
        }
    }
}

struct VerticalBondView: View {
    let thickness: CGFloat
    let length: CGFloat
    var body: some View {
        BondCylinderView(color: MoleculeColors.bond, width: thickness, height: length, orientation: .vertical)
    }
}

struct HorizontalBondView: View {
    let width: CGFloat
    let thickness: CGFloat
    var body: some View {
        BondCylinderView(color: MoleculeColors.bond, width: width, height: thickness, orientation: .horizontal)
    }
}

struct SingleBondView: View {
    let length: CGFloat
    let thickness: CGFloat
    var body: some View {
        BondCylinderView(color: MoleculeColors.bond, width: length, height: thickness, orientation: .horizontal)
    }
}

struct DoubleBondView: View {
    let length: CGFloat
    let thickness: CGFloat
    var body: some View {
        VStack(spacing: 2) {
            BondCylinderView(color: MoleculeColors.bond, width: length, height: thickness * 0.8, orientation: .horizontal)
            BondCylinderView(color: MoleculeColors.bond, width: length, height: thickness * 0.8, orientation: .horizontal)
        }
    }
}

struct TripleBondView: View {
    let length: CGFloat
    let thickness: CGFloat
    var body: some View {
        VStack(spacing: 2) {
            BondCylinderView(color: MoleculeColors.bond, width: length, height: thickness * 0.7, orientation: .horizontal)
            BondCylinderView(color: MoleculeColors.bond, width: length, height: thickness * 0.7, orientation: .horizontal)
            BondCylinderView(color: MoleculeColors.bond, width: length, height: thickness * 0.7, orientation: .horizontal)
        }
    }
}

// AtomSphereView is declared elsewhere in the project — not redeclared here.

// MARK: - Previews
struct HydrocarbonStructureView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            HydrocarbonStructureView(type: .alkane, carbonCount: 1)
            HydrocarbonStructureView(type: .alkene, carbonCount: 2)
            HydrocarbonStructureView(type: .alkyne, carbonCount: 3)
        }
        .padding()
        .previewLayout(.sizeThatFits)
    }
}
