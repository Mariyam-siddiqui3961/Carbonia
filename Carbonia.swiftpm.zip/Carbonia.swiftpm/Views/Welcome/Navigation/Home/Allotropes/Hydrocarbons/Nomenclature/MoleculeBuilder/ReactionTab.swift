import SwiftUI

enum ReactionType: String, CaseIterable, Identifiable {
    case combustion   = "Combustion"
    case addition     = "Addition"
    case substitution = "Substitution"

    var id: String { rawValue }
}

struct ReactionsTab: View {
    @State private var selectedReaction: ReactionType = .combustion

    var reactionEquation: String {
        switch selectedReaction {
        case .combustion:   return "CH\u{2084} + 2O\u{2082} \u{2192} CO\u{2082} + 2H\u{2082}O"
        case .addition:     return "C\u{2082}H\u{2084} + H\u{2082} \u{2192} C\u{2082}H\u{2086}"
        case .substitution: return "CH\u{2084} + Cl\u{2082} \u{2192} CH\u{2083}Cl + HCl"
        }
    }

    var reactionName: String {
        switch selectedReaction {
        case .combustion:   return "Combustion of Methane"
        case .addition:     return "Hydrogenation of Ethene"
        case .substitution: return "Chlorination of Methane"
        }
    }

    var reactionExplanation: String {
        switch selectedReaction {
        case .combustion:
            return "Combustion is a reaction with oxygen that produces carbon dioxide, water, and releases heat energy. This is how fuels like natural gas produce energy."
        case .addition:
            return "Addition reactions occur when atoms are added across a double or triple bond. Hydrogen adds to ethene to form ethane, converting a double bond to a single bond."
        case .substitution:
            return "Substitution reactions replace one atom or group with another. A hydrogen atom in methane is replaced by a chlorine atom to form chloromethane."
        }
    }

    var body: some View {
        Form {
            Section(header: Text("Select Reaction")) {
                Picker("Reaction Type", selection: $selectedReaction) {
                    ForEach(ReactionType.allCases) { r in
                        Text(r.rawValue).tag(r)
                    }
                }
                .pickerStyle(.segmented)
                .accessibilityLabel("Reaction type picker")
            }

            Section(header: Text("Reaction")) {
                VStack(alignment: .leading, spacing: 12) {
                    Text(reactionName)
                        .font(.headline)

                    Text(reactionEquation)
                        .font(.system(.title3, design: .monospaced))
                        .foregroundStyle(Color.blue)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 10))
                }
                .accessibilityElement(children: .combine)
                .accessibilityLabel("\(reactionName): \(reactionEquation)")
            }

            Section(header: Text("Explanation")) {
                Text(reactionExplanation)
                    .font(.subheadline)
                    .foregroundStyle(Color.secondary)
                    .lineSpacing(4)
            }

            Section(header: Text("Key Terms")) {
                termsList
            }
        }
    }

    @ViewBuilder
    private var termsList: some View {
        switch selectedReaction {
        case .combustion:
            KeyTermRow(term: "Reactants", value: "Methane + Oxygen")
            KeyTermRow(term: "Products",  value: "Carbon Dioxide + Water")
            KeyTermRow(term: "Energy",    value: "Exothermic (releases heat)")
        case .addition:
            KeyTermRow(term: "Reactants",    value: "Ethene + Hydrogen")
            KeyTermRow(term: "Products",     value: "Ethane")
            KeyTermRow(term: "Bond Change",  value: "Double → Single")
        case .substitution:
            KeyTermRow(term: "Reactants",  value: "Methane + Chlorine")
            KeyTermRow(term: "Products",   value: "Chloromethane + HCl")
            KeyTermRow(term: "Mechanism",  value: "H replaced by Cl")
        }
    }
}
