import SwiftUI

@available(iOS 17.0, *)
struct BuildMoleculeTab: View {
    @State private var carbonCount: Int = 0
    @State private var hydrogenCount: Int = 0
    @State private var aiTip: String = ""
    @State private var aiMoleculeInfo: String = ""
    @State private var isLoadingTip = false
    @State private var isLoadingInfo = false
    @State private var lastTipKey: String = ""
    @State private var showConfetti = false
    private let aiService = ChemistryAIService()

    // Colors matching CovalentBondingSection
    private let carbonColor   = Color(red: 0.55, green: 0.28, blue: 0.95)  // purple
    private let hydrogenColor = Color(red: 0.22, green: 0.55, blue: 0.95)  // blue

    // MARK: - Known molecules
    var detectedMolecule: (name: String, formula: String)? {
        switch (carbonCount, hydrogenCount) {
        case (1, 4):  return ("Methane",  "CH₄")
        case (2, 6):  return ("Ethane",   "C₂H₆")
        case (2, 4):  return ("Ethene",   "C₂H₄")
        case (2, 2):  return ("Ethyne",   "C₂H₂")
        case (3, 8):  return ("Propane",  "C₃H₈")
        case (3, 6):  return ("Propene",  "C₃H₆")
        case (4, 10): return ("Butane",   "C₄H₁₀")
        case (4, 8):  return ("Butene",   "C₄H₈")
        case (5, 12): return ("Pentane",  "C₅H₁₂")
        case (6, 14): return ("Hexane",   "C₆H₁₄")
        default:      return nil
        }
    }

    var totalAtoms: Int { carbonCount + hydrogenCount }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {

                // ── Header ──
                headerSection

                // ── Atom Counter Cards ──
                atomCounterSection

                // ── Workspace ──
                workspaceSection

                // ── Molecule detected ──
                if let mol = detectedMolecule {
                    detectedSection(mol)
                }

                // ── AI Tip ──
                if !aiTip.isEmpty {
                    aiTipSection
                }

                // ── Reset ──
                if totalAtoms > 0 {
                    Button(role: .destructive) {
                        withAnimation(.spring()) {
                            carbonCount = 0
                            hydrogenCount = 0
                            aiTip = ""
                            aiMoleculeInfo = ""
                            lastTipKey = ""
                        }
                    } label: {
                        Label("Reset Molecule", systemImage: "arrow.counterclockwise")
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.bordered)
                    .tint(Color.red)
                    .padding(.horizontal)
                }
            }
            .padding(.vertical)
        }
        .scrollIndicators(.hidden)
        .background(Color(.systemGroupedBackground))
        .onChange(of: carbonCount) { fetchAITip() }
        .onChange(of: hydrogenCount) { fetchAITip() }
    }

    // MARK: - Header

    private var headerSection: some View {
        VStack(spacing: 4) {
            Text("Molecule Builder")
                .font(.title2.bold())
            Text("Add carbon and hydrogen atoms to build a compound")
                .font(.caption)
                .foregroundStyle(Color.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal)
    }

    // MARK: - Atom Counter Cards

    private var atomCounterSection: some View {
        HStack(spacing: 14) {
            AtomCountCard(
                symbol: "C",
                name: "Carbon",
                count: carbonCount,
                color: carbonColor,
                textColor: Color.white,
                onAdd: { withAnimation(.spring(response: 0.3)) { carbonCount += 1 } },
                onRemove: { if carbonCount > 0 { withAnimation(.spring(response: 0.3)) { carbonCount -= 1 } } }
            )
            AtomCountCard(
                symbol: "H",
                name: "Hydrogen",
                count: hydrogenCount,
                color: hydrogenColor,
                textColor: Color.white,
                onAdd: { withAnimation(.spring(response: 0.3)) { hydrogenCount += 1 } },
                onRemove: { if hydrogenCount > 0 { withAnimation(.spring(response: 0.3)) { hydrogenCount -= 1 } } }
            )
        }
        .padding(.horizontal)
    }

    // MARK: - Workspace (visual atom display)

    private var workspaceSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("Workspace", systemImage: "circle.grid.3x3")
                    .font(.caption.bold())
                    .foregroundStyle(Color.secondary)
                    .textCase(.uppercase)
                    .tracking(0.8)
                Spacer()
                if totalAtoms > 0 {
                    Text("\(totalAtoms) atom\(totalAtoms == 1 ? "" : "s")")
                        .font(.caption)
                        .foregroundStyle(Color.secondary)
                }
            }
            .padding(.horizontal)

            ZStack {
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color(.secondarySystemGroupedBackground))
                    .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 3)

                if totalAtoms == 0 {
                    VStack(spacing: 10) {
                        Image(systemName: "plus.circle.dashed")
                            .font(.system(size: 40))
                            .foregroundStyle(.tertiary)
                        Text("Tap + to add atoms below")
                            .font(.subheadline)
                            .foregroundStyle(Color.secondary)
                    }
                } else {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(0..<carbonCount, id: \.self) { _ in
                                AtomView(symbol: "C", color: carbonColor,
                                         textColor: Color.white, size: 48)
                                .transition(.scale.combined(with: .opacity))
                            }
                            if carbonCount > 0 && hydrogenCount > 0 {
                                Image(systemName: "minus")
                                    .font(.caption)
                                    .foregroundStyle(Color.secondary)
                                    .padding(.horizontal, 4)
                            }
                            ForEach(0..<hydrogenCount, id: \.self) { _ in
                                AtomView(symbol: "H", color: hydrogenColor,
                                         textColor: Color.white, size: 48)
                                .transition(.scale.combined(with: .opacity))
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 16)
                    }
                }
            }
            .frame(height: 120)
            .padding(.horizontal)
        }
    }

    // MARK: - Detected Molecule

    private func detectedSection(_ mol: (name: String, formula: String)) -> some View {
        VStack(spacing: 12) {
            HStack(spacing: 14) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(Color.green)

                VStack(alignment: .leading, spacing: 2) {
                    Text("Molecule Identified!")
                        .font(.caption.bold())
                        .foregroundStyle(Color.green)
                        .textCase(.uppercase)
                        .tracking(0.5)
                    Text(mol.name)
                        .font(.title2.bold())
                    Text(mol.formula)
                        .font(.headline)
                        .foregroundStyle(Color.secondary)
                }
                Spacer()
            }

            if isLoadingInfo {
                HStack(spacing: 8) {
                    ProgressView().scaleEffect(0.8)
                    Text("Loading molecule info…")
                        .font(.caption)
                        .foregroundStyle(Color.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            } else if !aiMoleculeInfo.isEmpty {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "atom")
                        .foregroundStyle(Color.purple)
                        .font(.caption.bold())
                        .padding(.top, 1)
                    Text(aiMoleculeInfo)
                        .font(.caption)
                        .foregroundStyle(Color.secondary)
                        .lineSpacing(3)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding()
        .background(Color.green.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.green.opacity(0.25), lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .padding(.horizontal)
        .accessibilityLabel("\(mol.name) identified, formula \(mol.formula)")
    }

    // MARK: - AI Tip

    private var aiTipSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("AI Suggestion", systemImage: "atom")
                .font(.caption.bold())
                .foregroundStyle(Color.purple)
            Text(aiTip)
                .font(.subheadline)
                .foregroundStyle(Color.primary)
                .lineSpacing(3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.purple.opacity(0.07))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.purple.opacity(0.2), lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .padding(.horizontal)
    }

    // MARK: - Nearest molecule calculation (guaranteed correct)

    private struct MoleculeTarget {
        let name: String
        let formula: String
        let c: Int
        let h: Int
    }

    private let allMolecules: [MoleculeTarget] = [
        MoleculeTarget(name: "Methane",  formula: "CH₄",   c: 1, h: 4),
        MoleculeTarget(name: "Ethyne",   formula: "C₂H₂",  c: 2, h: 2),
        MoleculeTarget(name: "Ethene",   formula: "C₂H₄",  c: 2, h: 4),
        MoleculeTarget(name: "Ethane",   formula: "C₂H₆",  c: 2, h: 6),
        MoleculeTarget(name: "Propyne",  formula: "C₃H₄",  c: 3, h: 4),
        MoleculeTarget(name: "Propene",  formula: "C₃H₆",  c: 3, h: 6),
        MoleculeTarget(name: "Propane",  formula: "C₃H₈",  c: 3, h: 8),
        MoleculeTarget(name: "Butene",   formula: "C₄H₈",  c: 4, h: 8),
        MoleculeTarget(name: "Butane",   formula: "C₄H₁₀", c: 4, h: 10),
        MoleculeTarget(name: "Pentane",  formula: "C₅H₁₂", c: 5, h: 12),
        MoleculeTarget(name: "Hexane",   formula: "C₆H₁₄", c: 6, h: 14),
    ]

    /// Returns a guaranteed-correct suggestion string computed purely in Swift.
    private func computedSuggestion(c: Int, h: Int) -> String {
        // Only consider molecules that require adding atoms (never removing)
        let reachable = allMolecules.filter { $0.c >= c && $0.h >= h }
        guard let nearest = reachable.min(by: { ($0.c - c + $0.h - h) < ($1.c - c + $1.h - h) }) else {
            return "Keep adding atoms to build a molecule!"
        }
        let addC = nearest.c - c
        let addH = nearest.h - h
        var parts: [String] = []
        if addC > 0 { parts.append("Add \(addC) more carbon atom\(addC == 1 ? "" : "s")") }
        if addH > 0 { parts.append("\(addC > 0 ? "and " : "Add ")\(addH) more hydrogen atom\(addH == 1 ? "" : "s")") }
        if parts.isEmpty { return "You've completed \(nearest.name) (\(nearest.formula))!" }
        return parts.joined(separator: " ") + " to complete \(nearest.name) (\(nearest.formula))!"
    }

    private func fetchAITip() {
        let tipKey = "\(carbonCount)-\(hydrogenCount)"
        guard tipKey != lastTipKey else { return }
        lastTipKey = tipKey
        aiMoleculeInfo = ""

        if let mol = detectedMolecule {
            Task {
                isLoadingInfo = true
                isLoadingTip = false
                aiTip = ""
                let prompt = """
                The student has built \(mol.name) (\(mol.formula)) with \(carbonCount) carbon and \(hydrogenCount) hydrogen atoms.
                In 2 sentences: give one interesting real-world use of \(mol.name) and one fun fact.
                Be enthusiastic and encouraging. Keep it short.
                """
                aiMoleculeInfo = await aiService.chat(input: prompt)
                isLoadingInfo = false
            }
            return
        }

        guard carbonCount > 0 || hydrogenCount > 0 else {
            aiTip = ""
            return
        }

        // Use Swift-computed suggestion — always mathematically correct, no AI needed
        aiTip = computedSuggestion(c: carbonCount, h: hydrogenCount)
    }
}

// MARK: - Atom Count Card

private struct AtomCountCard: View {
    let symbol: String
    let name: String
    let count: Int
    let color: Color
    let textColor: Color
    let onAdd: () -> Void
    let onRemove: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            AtomView(symbol: symbol, color: color, textColor: textColor, size: 52)

            Text(name)
                .font(.caption.bold())
                .foregroundStyle(Color.secondary)

            Text("\(count)")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(count == 0 ? Color.secondary : Color.primary)
                .frame(minWidth: 40)
                .contentTransition(.numericText())

            HStack(spacing: 12) {
                Button(action: onRemove) {
                    Image(systemName: "minus.circle.fill")
                        .font(.title2)
                        .foregroundStyle(count == 0 ? Color.secondary.opacity(0.4) : Color.red)
                }
                .disabled(count == 0)

                Button(action: onAdd) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                        .foregroundStyle(color)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: Color.black.opacity(0.05), radius: 6, x: 0, y: 3)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(count > 0 ? color.opacity(0.3) : Color.clear, lineWidth: 1.5)
        )
        .accessibilityLabel("\(name): \(count) atoms")
    }
}
