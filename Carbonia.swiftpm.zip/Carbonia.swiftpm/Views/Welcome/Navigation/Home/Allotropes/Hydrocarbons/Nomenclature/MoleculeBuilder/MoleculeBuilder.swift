import SwiftUI

@available(iOS 17.0, *)
struct MoleculeBuilderView: View {
    var body: some View {
        MoleculeBuilderTabHost()
            .navigationTitle("Molecule Builder")
            .navigationBarTitleDisplayMode(.inline)
    }
}

/// Internal tab host — avoids nesting TabView inside NavigationStack.
@available(iOS 17.0, *)
private struct MoleculeBuilderTabHost: View {
    @State private var selectedTab = 0

    var body: some View {
        VStack(spacing: 0) {
            Picker("", selection: $selectedTab) {
                Label("Build", systemImage: "circle.grid.cross").tag(0)
                Label("Reactions", systemImage: "flame").tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.vertical, 10)
            .background(Color(.systemGroupedBackground))

            Divider()

            Group {
                if selectedTab == 0 {
                    BuildMoleculeTab()
                } else {
                    ReactionsTab()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color(.systemGroupedBackground))
    }
}
