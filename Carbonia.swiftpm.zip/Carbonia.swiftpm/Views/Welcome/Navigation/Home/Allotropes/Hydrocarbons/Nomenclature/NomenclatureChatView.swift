import SwiftUI

@available(iOS 17.0, *)
struct NomenclatureChatView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var messages: [ChatMessage] = []
    @State private var inputText = ""
    @State private var isLoading = false
    @State private var aiService = ChemistryAIService()

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                messageList
                if messages.count <= 1 && !isLoading {
                    hintQuestions
                }
                inputBar
            }
            .navigationTitle("Nomenclature Assistant")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear {
                guard messages.isEmpty else { return }
                Task { await startConversation() }
            }
        }
    }

    private var hintQuestions: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(["How do I name a branched alkane?",
                         "What's the difference between alkene and alkyne?",
                         "How does IUPAC numbering work?"], id: \.self) { q in
                    Button {
                        inputText = q
                        Task { await sendMessage() }
                    } label: {
                        Text(q)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(Color.blue)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.blue.opacity(0.1), in: Capsule())
                            .overlay(Capsule().stroke(Color.blue.opacity(0.3), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .background(.thinMaterial)
    }

    private var messageList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(messages) { msg in
                        ChatBubble(message: msg).id(msg.id)
                    }
                    if isLoading {
                        LoadingBubble().id("loading")
                    }
                }
                .padding()
            }
            .scrollIndicators(.hidden)
            .onChange(of: messages.count) {
                if let lastId = messages.last?.id {
                    withAnimation { proxy.scrollTo(lastId, anchor: .bottom) }
                }
            }
        }
    }

    private var inputBar: some View {
        HStack(spacing: 12) {
            TextField("Ask about IUPAC naming rules...", text: $inputText)
                .padding(12)
                .background(Color(.systemGray6), in: Capsule())
                .disabled(isLoading)
                .submitLabel(.send)
                .onSubmit { Task { await sendMessage() } }
                .accessibilityLabel("Message input field")

            Button {
                Task { await sendMessage() }
            } label: {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(inputText.isEmpty || isLoading ? .secondary : Color.blue)
            }
            .disabled(inputText.isEmpty || isLoading)
            .accessibilityLabel("Send message")
        }
        .padding()
        .background(.thinMaterial)
    }

    private func startConversation() async {
        isLoading = true
        let response = await aiService.explainNomenclature()
        messages.append(ChatMessage(text: response, isUser: false))
        isLoading = false
    }

    private func sendMessage() async {
        let text = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        inputText = ""
        messages.append(ChatMessage(text: text, isUser: true))
        isLoading = true
        let prompt = "Student Question about IUPAC Naming: \(text). Answer as a chemistry tutor. If the question is not related to organic chemistry or IUPAC naming, politely redirect them back to chemistry."
        let response = await aiService.chat(input: prompt)
        messages.append(ChatMessage(text: response, isUser: false))
        isLoading = false
    }
}
