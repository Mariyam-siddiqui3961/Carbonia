import SceneKit
import UIKit

// MARK: - Allotrope 3D Scene Factory

struct AllotropeSceneFactory {
    static func scene(for name: String) -> SCNScene {
        switch name.lowercased() {
        case "diamond":   return DiamondScene.make()
        case "graphite":  return GraphiteScene.make()
        case "fullerene": return FullereneScene.make()
        default:          return AmorphousScene.make()
        }
    }

    // MARK: - Conductivity Visual Effects

    static func applyConductivityEffect(to scene: SCNScene?, conducts: Bool, allotropeName: String) {
        guard let scene = scene else { return }
        removeConductivityEffect(from: scene)

        if conducts {
            addElectronFlow(to: scene, allotropeName: allotropeName)
        } else {
            addInsulatorGlow(to: scene)
        }
    }

    static func removeConductivityEffect(from scene: SCNScene?) {
        guard let scene = scene else { return }
        scene.rootNode.childNodes(passingTest: { node, _ in
            node.name == "electron" || node.name == "insulator_glow" || node.name == "electron_emitter"
        }).forEach { $0.removeFromParentNode() }

        // Remove any glow/emission overrides on atom nodes
        scene.rootNode.enumerateChildNodes { node, _ in
            if node.name == "atom_glow_removed" {
                node.name = nil
            }
            if let geo = node.geometry {
                for mat in geo.materials {
                    mat.emission.contents = UIColor.black
                }
            }
        }
    }

    // Flowing electron spheres that travel through/around the structure
    private static func addElectronFlow(to scene: SCNScene, allotropeName: String) {
        let root = scene.rootNode

        // Add a warm electric glow to atom materials
        root.enumerateChildNodes { node, _ in
            guard let geo = node.geometry, geo is SCNSphere else { return }
            for mat in geo.materials {
                mat.emission.contents = UIColor(red: 0.1, green: 0.85, blue: 0.3, alpha: 0.35)
            }
        }

        // Spawn animated electron particles
        let numElectrons = allotropeName.lowercased() == "graphite" ? 8 : 6
        let radius: Float = allotropeName.lowercased() == "fullerene" ? 2.2 : 1.8

        for i in 0..<numElectrons {
            let electron = makeElectronNode()
            electron.name = "electron"
            root.addChildNode(electron)

            // Each electron orbits on a slightly tilted plane
            let tilt = Float(i) * Float.pi / Float(numElectrons)
            let orbitDuration = Double.random(in: 1.8...3.2)
            let startAngle = Float(i) * 2 * Float.pi / Float(numElectrons)

            // Animate along circular path
            let steps = 60
            var positions: [SCNVector3] = []
            for s in 0..<steps {
                let angle = startAngle + Float(s) * 2 * Float.pi / Float(steps)
                let x = radius * cos(angle)
                let y = radius * sin(angle) * cos(tilt)
                let z = radius * sin(angle) * sin(tilt)
                positions.append(SCNVector3(x, y, z))
            }

            let moveActions = positions.map { pos -> SCNAction in
                SCNAction.move(to: pos, duration: orbitDuration / Double(steps))
            }
            let orbit = SCNAction.repeatForever(SCNAction.sequence(moveActions))
            electron.runAction(orbit)

            // Pulse glow
            let pulseIn = SCNAction.customAction(duration: 0.4) { node, t in
                (node.geometry?.firstMaterial?.emission.contents as? UIColor).map { _ in
                    node.geometry?.firstMaterial?.emission.contents =
                        UIColor(red: 0.1, green: 0.85, blue: 0.3, alpha: 0.4 + 0.6 * CGFloat(t / 0.4))
                }
            }
            let pulseOut = SCNAction.customAction(duration: 0.4) { node, t in
                node.geometry?.firstMaterial?.emission.contents =
                    UIColor(red: 0.1, green: 0.85, blue: 0.3, alpha: 1.0 - 0.6 * CGFloat(t / 0.4))
            }
            electron.runAction(SCNAction.repeatForever(SCNAction.sequence([pulseIn, pulseOut])))
        }

        // Animated "lightning" line along the structure
        addElectricArc(to: root, allotropeName: allotropeName)
    }

    private static func makeElectronNode() -> SCNNode {
        let geo = SCNSphere(radius: 0.12)
        let mat = SCNMaterial()
        mat.diffuse.contents = UIColor(red: 0.2, green: 0.95, blue: 0.45, alpha: 1)
        mat.emission.contents = UIColor(red: 0.1, green: 0.85, blue: 0.3, alpha: 1)
        mat.specular.contents = UIColor.white
        mat.shininess = 1.0
        geo.materials = [mat]
        let node = SCNNode(geometry: geo)
        return node
    }

    private static func addElectricArc(to root: SCNNode, allotropeName: String) {
        // A glowing cylinder that sweeps to imply charge movement
        let arc = SCNNode()
        arc.name = "electron"

        let geo = SCNCylinder(radius: 0.04, height: 3.5)
        let mat = SCNMaterial()
        mat.diffuse.contents = UIColor(red: 0.2, green: 0.95, blue: 0.45, alpha: 0.7)
        mat.emission.contents = UIColor(red: 0.1, green: 0.85, blue: 0.3, alpha: 0.7)
        geo.materials = [mat]
        arc.geometry = geo
        arc.position = SCNVector3(0, 0, 0)
        arc.eulerAngles = SCNVector3(0, 0, Float.pi / 2)

        let rotate = SCNAction.rotateBy(x: CGFloat(Float.pi * 2), y: CGFloat(Float.pi), z: 0, duration: 2.5)
        arc.runAction(SCNAction.repeatForever(rotate))

        let fadeSeq = SCNAction.repeatForever(SCNAction.sequence([
            SCNAction.fadeOpacity(to: 0.9, duration: 0.3),
            SCNAction.fadeOpacity(to: 0.3, duration: 0.3)
        ]))
        arc.runAction(fadeSeq)

        root.addChildNode(arc)
    }

    // Red X-like glow for insulators
    private static func addInsulatorGlow(to scene: SCNScene) {
        let root = scene.rootNode

        // Tint atoms with a dull red/orange to signal blocked charge
        root.enumerateChildNodes { node, _ in
            guard let geo = node.geometry, geo is SCNSphere else { return }
            for mat in geo.materials {
                mat.emission.contents = UIColor(red: 0.9, green: 0.15, blue: 0.1, alpha: 0.25)
            }
        }

        // Floating "barrier" rings
        for i in 0..<3 {
            let ring = makeBarrierRing(radius: 1.2 + Float(i) * 0.5)
            ring.name = "insulator_glow"
            root.addChildNode(ring)

            let rot = SCNAction.rotateBy(
                x: CGFloat(Float.pi),
                y: CGFloat(Float.pi * Float(i + 1)),
                z: 0,
                duration: Double(3 + i)
            )
            ring.runAction(SCNAction.repeatForever(rot))

            let pulse = SCNAction.repeatForever(SCNAction.sequence([
                SCNAction.fadeOpacity(to: 0.85, duration: 0.5),
                SCNAction.fadeOpacity(to: 0.25, duration: 0.5)
            ]))
            ring.runAction(pulse)
        }
    }

    private static func makeBarrierRing(radius: Float) -> SCNNode {
        let geo = SCNTorus(ringRadius: CGFloat(radius), pipeRadius: 0.04)
        let mat = SCNMaterial()
        mat.diffuse.contents = UIColor(red: 1.0, green: 0.25, blue: 0.2, alpha: 0.8)
        mat.emission.contents = UIColor(red: 1.0, green: 0.1, blue: 0.1, alpha: 0.6)
        geo.materials = [mat]
        return SCNNode(geometry: geo)
    }
}

// MARK: - Shared Helpers

private func carbonSphere(radius: CGFloat, color: UIColor = UIColor(red: 0.15, green: 0.15, blue: 0.15, alpha: 1)) -> SCNNode {
    let geo = SCNSphere(radius: radius)
    let mat = SCNMaterial()
    mat.diffuse.contents = color
    mat.specular.contents = UIColor.white
    mat.shininess = 0.8
    geo.materials = [mat]
    return SCNNode(geometry: geo)
}

private func bondCylinder(from a: SCNVector3, to b: SCNVector3, radius: CGFloat = 0.06, color: UIColor = UIColor(white: 0.5, alpha: 1)) -> SCNNode {
    let dx = b.x - a.x
    let dy = b.y - a.y
    let dz = b.z - a.z
    let length = sqrt(dx*dx + dy*dy + dz*dz)
    let mid = SCNVector3((a.x+b.x)/2, (a.y+b.y)/2, (a.z+b.z)/2)

    let geo = SCNCylinder(radius: radius, height: CGFloat(length))
    let mat = SCNMaterial()
    mat.diffuse.contents = color
    mat.specular.contents = UIColor.white
    mat.shininess = 0.4
    geo.materials = [mat]

    let node = SCNNode(geometry: geo)
    node.position = mid

    let cross = SCNVector3(
        1*dz - 0*dy,
        0*dx - 0*dz,
        0*dy - 1*dx
    )
    let dot = Float(1 * dy)
    let mag = sqrt(dx*dx + dy*dy + dz*dz)
    let angle = acos(dot / mag)
    if cross.x != 0 || cross.y != 0 || cross.z != 0 {
        node.rotation = SCNVector4(cross.x, cross.y, cross.z, angle)
    }
    return node
}

private func baseScene() -> SCNScene {
    let scene = SCNScene()
    scene.background.contents = UIColor.clear

    let ambient = SCNNode()
    ambient.light = SCNLight()
    ambient.light!.type = .ambient
    ambient.light!.color = UIColor(white: 0.4, alpha: 1)
    scene.rootNode.addChildNode(ambient)

    let omni = SCNNode()
    omni.light = SCNLight()
    omni.light!.type = .omni
    omni.light!.color = UIColor(white: 1.0, alpha: 1)
    omni.position = SCNVector3(10, 10, 10)
    scene.rootNode.addChildNode(omni)

    return scene
}

private func addSpin(to node: SCNNode, duration: Double = 12) {
    let spin = SCNAction.rotateBy(x: 0, y: CGFloat(2 * Double.pi), z: 0, duration: duration)
    node.runAction(SCNAction.repeatForever(spin))
}

// MARK: - Diamond
// Tetrahedral crystal lattice

private struct DiamondScene {
    static func make() -> SCNScene {
        let scene = baseScene()
        let root = SCNNode()

        let a: Float = 1.6
        let sites: [SCNVector3] = [
            SCNVector3(0,0,0), SCNVector3(a,0,0), SCNVector3(0,a,0), SCNVector3(a,a,0),
            SCNVector3(0,0,a), SCNVector3(a,0,a), SCNVector3(0,a,a), SCNVector3(a,a,a),
            SCNVector3(a/2,a/2,0), SCNVector3(a/2,0,a/2), SCNVector3(0,a/2,a/2),
            SCNVector3(a,a/2,a/2), SCNVector3(a/2,a,a/2), SCNVector3(a/2,a/2,a),
            SCNVector3(a/4,a/4,a/4), SCNVector3(3*a/4,3*a/4,a/4),
            SCNVector3(3*a/4,a/4,3*a/4), SCNVector3(a/4,3*a/4,3*a/4)
        ]

        let ox: Float = -a/2, oy: Float = -a/2, oz: Float = -a/2

        for s in sites {
            let node = carbonSphere(radius: 0.18, color: UIColor(red: 0.5, green: 0.85, blue: 1.0, alpha: 1))
            node.position = SCNVector3(s.x+ox, s.y+oy, s.z+oz)
            root.addChildNode(node)
        }

        let bonds: [(Int,Int)] = [
            (14,0),(14,8),(14,9),(14,10),
            (15,1),(15,8),(15,11),(15,12),
            (16,5),(16,9),(16,11),(16,13),
            (17,6),(17,10),(17,12),(17,13)
        ]
        for (i,j) in bonds {
            let p1 = SCNVector3(sites[i].x+ox, sites[i].y+oy, sites[i].z+oz)
            let p2 = SCNVector3(sites[j].x+ox, sites[j].y+oy, sites[j].z+oz)
            root.addChildNode(bondCylinder(from: p1, to: p2, color: UIColor(white: 0.6, alpha: 1)))
        }

        scene.rootNode.addChildNode(root)
        return scene
    }
}

// MARK: - Graphite
// Stacked hexagonal layers

private struct GraphiteScene {
    static func make() -> SCNScene {
        let scene = baseScene()
        let root = SCNNode()

        let bondLen: Float = 0.7
        let layerSep: Float = 1.0
        let numLayers = 3

        for layer in 0..<numLayers {
            let y = Float(layer) * layerSep - Float(numLayers-1) * layerSep / 2
            let xOff: Float = layer % 2 == 0 ? 0 : bondLen * 0.5
            let layerNode = SCNNode()
            layerNode.position.y = y

            for row in -1...1 {
                for col in -1...1 {
                    let cx = Float(col) * bondLen * 1.732 + xOff
                    let cz = Float(row) * bondLen * 1.5
                    var ring: [SCNNode] = []

                    for i in 0..<6 {
                        let angle = Float(i) * Float.pi / 3
                        let x = cx + bondLen * cos(angle)
                        let z = cz + bondLen * sin(angle)
                        let atom = carbonSphere(radius: 0.14,
                            color: layer % 2 == 0
                                ? UIColor(white: 0.2, alpha: 1)
                                : UIColor(white: 0.45, alpha: 1))
                        atom.position = SCNVector3(x, 0, z)
                        layerNode.addChildNode(atom)
                        ring.append(atom)
                    }
                    for i in 0..<6 {
                        layerNode.addChildNode(bondCylinder(
                            from: ring[i].position,
                            to: ring[(i+1)%6].position,
                            radius: 0.05,
                            color: UIColor(white: 0.35, alpha: 1)))
                    }
                }
            }
            root.addChildNode(layerNode)
        }

        scene.rootNode.addChildNode(root)
        return scene
    }
}

// MARK: - Fullerene C60
// 60-vertex truncated icosahedron

private struct FullereneScene {
    static func make() -> SCNScene {
        let scene = baseScene()
        let root = SCNNode()

        let phi = Float((1 + sqrt(5.0)) / 2)
        let r: Float = 2.0

        let icoVerts: [SCNVector3] = [
            SCNVector3(0,1,phi), SCNVector3(0,-1,phi), SCNVector3(0,1,-phi), SCNVector3(0,-1,-phi),
            SCNVector3(1,phi,0), SCNVector3(-1,phi,0), SCNVector3(1,-phi,0), SCNVector3(-1,-phi,0),
            SCNVector3(phi,0,1), SCNVector3(-phi,0,1), SCNVector3(phi,0,-1), SCNVector3(-phi,0,-1)
        ]

        let edges: [(Int,Int)] = [
            (0,1),(0,4),(0,5),(0,8),(0,9),
            (1,6),(1,7),(1,8),(1,9),(2,3),
            (2,4),(2,5),(2,10),(2,11),(3,6),
            (3,7),(3,10),(3,11),(4,5),(4,8),
            (4,10),(5,9),(5,11),(6,7),(6,8),
            (6,10),(7,9),(7,11),(8,10),(9,11)
        ]

        var raw: [SCNVector3] = []
        for (i,j) in edges {
            let a = icoVerts[i], b = icoVerts[j]
            func lerp(_ t: Float) -> SCNVector3 {
                SCNVector3(a.x+(b.x-a.x)*t, a.y+(b.y-a.y)*t, a.z+(b.z-a.z)*t)
            }
            raw.append(lerp(1/3))
            raw.append(lerp(2/3))
        }

        // Normalise to sphere surface
        var unique: [SCNVector3] = []
        for v in raw {
            let len = sqrt(v.x*v.x + v.y*v.y + v.z*v.z)
            let n = SCNVector3(v.x/len*r, v.y/len*r, v.z/len*r)
            let isDup = unique.contains {
                let dx=$0.x-n.x, dy=$0.y-n.y, dz=$0.z-n.z
                return sqrt(dx*dx+dy*dy+dz*dz) < 0.05
            }
            if !isDup { unique.append(n) }
        }

        for pos in unique {
            let atom = carbonSphere(radius: 0.15, color: UIColor(red: 0.2, green: 0.6, blue: 1.0, alpha: 1))
            atom.position = pos
            root.addChildNode(atom)
        }

        let thresh: Float = r * 0.44
        for i in 0..<unique.count {
            for j in (i+1)..<unique.count {
                let dx=unique[i].x-unique[j].x
                let dy=unique[i].y-unique[j].y
                let dz=unique[i].z-unique[j].z
                if sqrt(dx*dx+dy*dy+dz*dz) < thresh {
                    root.addChildNode(bondCylinder(
                        from: unique[i], to: unique[j],
                        radius: 0.05,
                        color: UIColor(white: 0.45, alpha: 1)))
                }
            }
        }

        scene.rootNode.addChildNode(root)
        return scene
    }
}

// MARK: - Amorphous Carbon
// Random cluster

private struct AmorphousScene {
    static func make() -> SCNScene {
        let scene = baseScene()
        let root = SCNNode()

        var positions: [SCNVector3] = []
        srand48(42)

        for _ in 0..<28 {
            let x = Float(drand48() * 4 - 2)
            let y = Float(drand48() * 4 - 2)
            let z = Float(drand48() * 4 - 2)
            let pos = SCNVector3(x, y, z)
            let overlap = positions.contains {
                let dx=$0.x-x, dy=$0.y-y, dz=$0.z-z
                return sqrt(dx*dx+dy*dy+dz*dz) < 0.5
            }
            if !overlap { positions.append(pos) }
        }

        for pos in positions {
            let g = CGFloat(Float.random(in: 0.15...0.45))
            let atom = carbonSphere(radius: 0.16, color: UIColor(white: g, alpha: 1))
            atom.position = pos
            root.addChildNode(atom)
        }

        let maxBond: Float = 1.1
        for i in 0..<positions.count {
            for j in (i+1)..<positions.count {
                let dx=positions[i].x-positions[j].x
                let dy=positions[i].y-positions[j].y
                let dz=positions[i].z-positions[j].z
                if sqrt(dx*dx+dy*dy+dz*dz) < maxBond {
                    root.addChildNode(bondCylinder(
                        from: positions[i], to: positions[j],
                        radius: 0.05,
                        color: UIColor(white: 0.4, alpha: 1)))
                }
            }
        }

        scene.rootNode.addChildNode(root)
        return scene
    }
}
