import SwiftUI

@available(iOS 17.0, *)
struct MainTabView: View {
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                LearnMenuView()
            }
            .tabItem {
                Label("Learn", systemImage: "house.fill")
            }
            .tag(0)

            NavigationStack {
                NomenclatureView()
            }
            .tabItem {
                Label("Nomenclature", systemImage: "text.book.closed.fill")
            }
            .tag(1)
        }
        .toolbarBackground(.ultraThinMaterial, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .tint(Color.blue)
    }
}
