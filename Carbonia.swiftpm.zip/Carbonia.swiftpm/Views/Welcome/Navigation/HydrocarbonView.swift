import SwiftUI

enum HydrocarbonType: String, CaseIterable, Identifiable {
    case alkane = "Alkane"
    case alkene = "Alkene"
    case alkyne = "Alkyne"

    var id: String { rawValue }

    /// Minimum carbon atoms for a valid chain of this type.
    var minimumCarbons: Int {
        switch self {
        case .alkane: return 1
        case .alkene: return 2
        case .alkyne: return 2
        }
    }

    var suffix: String {
        switch self {
        case .alkane: return "-ane"
        case .alkene: return "-ene"
        case .alkyne: return "-yne"
        }
    }

    var bondType: String {
        switch self {
        case .alkane: return "Single bond (C–C)"
        case .alkene: return "Double bond (C=C)"
        case .alkyne: return "Triple bond (C≡C)"
        }
    }
}

@available(iOS 17.0, *)
struct HydrocarbonView: View {

    @State private var selectedType: HydrocarbonType = .alkane
    @State private var carbonCount: Int = 2

    // AI
    @State private var aiReaction: ReactionSuggestion?
    @State private var isLoadingAI = false
    @State private var showAISuggestion = false

    private let aiService = ChemistryAIService()

    // MARK: - Computed

    var formula: String {
        switch selectedType {
        case .alkane: return "C\(carbonCount)H\(2 * carbonCount + 2)"
        case .alkene: return "C\(carbonCount)H\(2 * carbonCount)"
        case .alkyne: return "C\(carbonCount)H\(2 * carbonCount - 2)"
        }
    }

    var carbonPrefix: String {
        let prefixes = [1:"meth",2:"eth",3:"prop",4:"but",5:"pent",
                        6:"hex",7:"hept",8:"oct",9:"non",10:"dec"]
        return prefixes[carbonCount] ?? ""
    }

    var moleculeName: String {
        switch selectedType {
        case .alkane: return carbonPrefix + "ane"
        case .alkene: return carbonPrefix + "ene"
        case .alkyne: return carbonPrefix + "yne"
        }
    }

    var structureString: String {
        let bond: String = {
            switch selectedType {
            case .alkane: return "–"
            case .alkene: return "="
            case .alkyne: return "≡"
            }
        }()
        guard carbonCount > 1 else { return "C" }
        var s = "C"
        for i in 1..<carbonCount {
            s += " \(i == 1 ? bond : "–") C"
        }
        return s
    }

    var generalFormulaText: Text {
        switch selectedType {
        case .alkane:
            return Text("C\(Text("n").font(.caption).baselineOffset(-4))H\(Text("2n+2").font(.caption).baselineOffset(-4))")
        case .alkene:
            return Text("C\(Text("n").font(.caption).baselineOffset(-4))H\(Text("2n").font(.caption).baselineOffset(-4))")
        case .alkyne:
            return Text("C\(Text("n").font(.caption).baselineOffset(-4))H\(Text("2n−2").font(.caption).baselineOffset(-4))")
        }
    }

    // MARK: - Body

    var body: some View {
        Form {
            HydrocarbonTypeSection(selectedType: $selectedType)
            HydrocarbonCarbonSection(
                carbonCount: $carbonCount,
                carbonPrefix: carbonPrefix,
                minCarbons: selectedType.minimumCarbons
            )
            HydrocarbonMoleculeSection(
                moleculeName: moleculeName,
                formula: formula,
                structureString: structureString,
                selectedType: selectedType,
                carbonCount: carbonCount
            )
            HydrocarbonPropertiesSection(
                generalFormulaText: generalFormulaText,
                bondType: selectedType.bondType,
                suffix: selectedType.suffix
            )
            HydrocarbonAISection(
                showAISuggestion: showAISuggestion,
                isLoadingAI: isLoadingAI,
                aiReaction: aiReaction,
                onLoadReaction: {
                    Task { await loadAIReaction() }
                }
            )
        }
        .navigationTitle("Hydrocarbons")
        .onChange(of: selectedType) {
            // Clamp carbon count to new minimum
            carbonCount = max(carbonCount, selectedType.minimumCarbons)
            resetAISuggestion()
        }
        .onChange(of: carbonCount) {
            resetAISuggestion()
        }
    }

    // MARK: - Logic

    private func loadAIReaction() async {
        showAISuggestion = true
        isLoadingAI = true
        aiReaction = await aiService.suggestReaction(
            moleculeName: moleculeName.capitalized,
            formula: formula,
            type: selectedType.rawValue
        )
        isLoadingAI = false
    }

    private func resetAISuggestion() {
        showAISuggestion = false
        aiReaction = nil
    }
}
