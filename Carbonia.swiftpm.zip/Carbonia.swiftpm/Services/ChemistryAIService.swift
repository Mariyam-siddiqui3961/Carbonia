import SwiftUI
import FoundationModels

// MARK: - Chemistry AI Service

@available(iOS 17.0, *)
@Observable
@MainActor
class ChemistryAIService {
    
    private var session: LanguageModelSession?
    var isAvailable: Bool = false
    
    init() {
        Task {
            await checkAvailability()
        }
    }
    
    /*private func checkAvailability() async {
        do {
            let newSession = try LanguageModelSession()
            self.session = newSession
            self.isAvailable = true
        } catch {
            self.session = nil
            self.isAvailable = false
        }
    }*/
    private func checkAvailability() async {
        // LanguageModelSession initializer does not throw; create directly and set availability
        let newSession = LanguageModelSession()
        self.session = newSession
        self.isAvailable = true
    }
    // MARK: - Allotrope Explanation
    
    func explainAllotrope(name: String, structure: String, properties: [String]) async -> String {
        guard isAvailable, let session = session else {
            return getFallbackAllotropeExplanation(name: name)
        }
        
        let prompt = """
        You are a friendly chemistry tutor. Explain the carbon allotrope "\(name)" in 1-2 simple sentences for a student. 
        Structure: \(structure). Properties: \(properties.joined(separator: ", ")).
        Be engaging and educational. Do not use complex terminology.
        """
        
        do {
            let response = try await session.respond(to: prompt)
            return response.content
        } catch {
            return getFallbackAllotropeExplanation(name: name)
        }
    }
    
    private func getFallbackAllotropeExplanation(name: String) -> String {
        switch name.lowercased() {
        case "diamond":
            return "Diamond is carbon's hardest form! Each carbon atom bonds to four others in a perfect 3D pattern, making it incredibly strong and sparkly."
        case "graphite":
            return "Graphite has carbon arranged in slippery layers that slide over each other. That's why it works great in pencils!"
        case "fullerene":
            return "Fullerenes are tiny carbon cages shaped like soccer balls! Scientists use them in nanotechnology and medicine."
        case "amorphous carbon":
            return "Amorphous carbon has no fixed pattern—it's like a jumbled pile of carbon atoms. Charcoal and soot are examples!"
        default:
            return "This is a fascinating form of carbon with unique properties!"
        }
    }
    
    // MARK: - General Chat
    
    func chat(input: String) async -> String {
        guard isAvailable, let session = session else {
            return "I'm sorry, I can't chat right now. Please try again later."
        }
        
        do {
            let response = try await session.respond(to: input)
            return response.content
        } catch {
            return "I'm having trouble connecting to my knowledge base. Error: \(error.localizedDescription)"
        }
    }
    
    // MARK: - Reaction Suggestion
    
    func suggestReaction(moleculeName: String, formula: String, type: String) async -> ReactionSuggestion {
        guard isAvailable, let session = session else {
            return getFallbackReaction(moleculeName: moleculeName, type: type)
        }
        
        let prompt = """
        You are a chemistry tutor. For the hydrocarbon \(moleculeName) (\(formula)), which is an \(type):
        1. Suggest ONE simple reaction (combustion, addition, or substitution)
        2. Write the reaction equation
        3. Explain in 1 sentence why this reaction happens
        
        Format your response exactly as:
        REACTION: [equation]
        TYPE: [reaction type]
        EXPLANATION: [one sentence]
        """
        
        do {
            let response = try await session.respond(to: prompt)
            return parseReactionResponse(response.content, moleculeName: moleculeName, type: type)
        } catch {
            return getFallbackReaction(moleculeName: moleculeName, type: type)
        }
    }
    
    private func parseReactionResponse(_ response: String, moleculeName: String, type: String) -> ReactionSuggestion {
        let lines = response.components(separatedBy: "\n")
        var equation = ""
        var reactionType = "Combustion"
        var explanation = ""
        
        for line in lines {
            if line.hasPrefix("REACTION:") {
                equation = line.replacingOccurrences(of: "REACTION:", with: "").trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("TYPE:") {
                reactionType = line.replacingOccurrences(of: "TYPE:", with: "").trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("EXPLANATION:") {
                explanation = line.replacingOccurrences(of: "EXPLANATION:", with: "").trimmingCharacters(in: .whitespaces)
            }
        }
        
        if equation.isEmpty {
            return getFallbackReaction(moleculeName: moleculeName, type: type)
        }
        
        return ReactionSuggestion(equation: equation, type: reactionType, explanation: explanation)
    }
    
    private func getFallbackReaction(moleculeName: String, type: String) -> ReactionSuggestion {
        switch type.lowercased() {
        case "alkane":
            return ReactionSuggestion(
                equation: "\(moleculeName) + O₂ → CO₂ + H₂O",
                type: "Combustion",
                explanation: "Alkanes burn in oxygen to release energy, producing carbon dioxide and water."
            )
        case "alkene":
            return ReactionSuggestion(
                equation: "\(moleculeName) + H₂ → Alkane",
                type: "Addition",
                explanation: "The double bond in alkenes can break to add hydrogen atoms, forming an alkane."
            )
        case "alkyne":
            return ReactionSuggestion(
                equation: "\(moleculeName) + 2H₂ → Alkane",
                type: "Addition",
                explanation: "Alkynes can add two hydrogen molecules across their triple bond to form alkanes."
            )
        default:
            return ReactionSuggestion(
                equation: "Hydrocarbon + O₂ → CO₂ + H₂O",
                type: "Combustion",
                explanation: "Hydrocarbons release energy when burned with oxygen."
            )
        }
    }
    
    // MARK: - Molecule Identification
    
    func identifyMolecule(carbonCount: Int, hydrogenCount: Int) async -> MoleculeIdentification {
        guard isAvailable, let session = session else {
            return getFallbackIdentification(carbonCount: carbonCount, hydrogenCount: hydrogenCount)
        }
        
        let prompt = """
        A molecule has \(carbonCount) carbon atoms and \(hydrogenCount) hydrogen atoms.
        1. Name this molecule (if it's a valid hydrocarbon)
        2. What type is it (alkane, alkene, or alkyne)?
        3. Give a fun fact in 1 sentence
        
        Format exactly as:
        NAME: [molecule name]
        TYPE: [alkane/alkene/alkyne]
        FACT: [one fun fact]
        """
        
        do {
            let response = try await session.respond(to: prompt)
            return parseMoleculeResponse(response.content, carbonCount: carbonCount, hydrogenCount: hydrogenCount)
        } catch {
            return getFallbackIdentification(carbonCount: carbonCount, hydrogenCount: hydrogenCount)
        }
    }
    
    private func parseMoleculeResponse(_ response: String, carbonCount: Int, hydrogenCount: Int) -> MoleculeIdentification {
        let lines = response.components(separatedBy: "\n")
        var name = ""
        var type = ""
        var fact = ""
        
        for line in lines {
            if line.hasPrefix("NAME:") {
                name = line.replacingOccurrences(of: "NAME:", with: "").trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("TYPE:") {
                type = line.replacingOccurrences(of: "TYPE:", with: "").trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("FACT:") {
                fact = line.replacingOccurrences(of: "FACT:", with: "").trimmingCharacters(in: .whitespaces)
            }
        }
        
        if name.isEmpty {
            return getFallbackIdentification(carbonCount: carbonCount, hydrogenCount: hydrogenCount)
        }
        
        return MoleculeIdentification(name: name, type: type, funFact: fact)
    }
    
    private func getFallbackIdentification(carbonCount: Int, hydrogenCount: Int) -> MoleculeIdentification {
        // Determine molecule based on formula
        let alkaneH = 2 * carbonCount + 2
        let alkeneH = 2 * carbonCount
        let alkyneH = 2 * carbonCount - 2
        
        let prefixes = [1: "Meth", 2: "Eth", 3: "Prop", 4: "But", 5: "Pent",
                       6: "Hex", 7: "Hept", 8: "Oct", 9: "Non", 10: "Dec"]
        let prefix = prefixes[carbonCount] ?? "Unknown"
        
        if hydrogenCount == alkaneH {
            let name = prefix + "ane"
            return MoleculeIdentification(
                name: name,
                type: "Alkane",
                funFact: getMoleculeFact(name: name.lowercased())
            )
        } else if hydrogenCount == alkeneH && carbonCount >= 2 {
            let name = prefix + "ene"
            return MoleculeIdentification(
                name: name,
                type: "Alkene",
                funFact: getMoleculeFact(name: name.lowercased())
            )
        } else if hydrogenCount == alkyneH && carbonCount >= 2 {
            let name = prefix + "yne"
            return MoleculeIdentification(
                name: name,
                type: "Alkyne",
                funFact: getMoleculeFact(name: name.lowercased())
            )
        }
        
        return MoleculeIdentification(
            name: "Unknown",
            type: "Invalid",
            funFact: "This combination doesn't form a standard hydrocarbon. Try adjusting the atoms!"
        )
    }
    
    private func getMoleculeFact(name: String) -> String {
        switch name {
        case "methane":
            return "Methane is the main component of natural gas and is also found on other planets!"
        case "ethane":
            return "Ethane is used to make ethylene, which becomes plastic bottles and bags!"
        case "propane":
            return "Propane powers BBQ grills and can even fuel some vehicles!"
        case "butane":
            return "Butane is the fuel in most disposable lighters!"
        case "ethene":
            return "Ethene helps fruits ripen! Bananas release it as they mature."
        case "ethyne":
            return "Ethyne (acetylene) burns so hot it can cut through steel!"
        default:
            return "This hydrocarbon is part of the amazing world of organic chemistry!"
        }
    }
    
    // MARK: - Nomenclature Help
    
    func explainNomenclature() async -> String {
        guard isAvailable, let session = session else {
            return getFallbackNomenclatureExplanation()
        }
        
        let prompt = """
        You are a friendly chemistry tutor specializing in IUPAC nomenclature. 
        Briefly introduce yourself and offer to help the student with naming rules for alkanes, alkenes, or alkynes. 
        Keep it encouraging and concise (1-2 sentences).
        """
        
        do {
            let response = try await session.respond(to: prompt)
            return response.content
        } catch {
            return getFallbackNomenclatureExplanation()
        }
    }
    
    private func getFallbackNomenclatureExplanation() -> String {
        return "Hi there! I'm your IUPAC Naming Assistant. I can help you understand rules for naming chains, identifying branches, and handling double or triple bonds. What would you like to learn about today?"
    }
}

// MARK: - Data Models

struct ReactionSuggestion {
    let equation: String
    let type: String
    let explanation: String
}

struct MoleculeIdentification {
    let name: String
    let type: String
    let funFact: String
}

