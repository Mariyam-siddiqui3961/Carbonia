import SwiftUI

struct Atom: Identifiable {
    let id = UUID()
    let symbol: String
}

struct AtomView: View {
    let symbol: String
    let color: Color
    let textColor: Color
    var size: CGFloat = 44

    var body: some View {
        ZStack {
            Circle()
                .fill(
                    RadialGradient(
                        colors: [color.opacity(0.7), color],
                        center: .topLeading,
                        startRadius: 0,
                        endRadius: size
                    )
                )
                .frame(width: size, height: size)
                .shadow(color: color.opacity(0.4), radius: 4, x: 0, y: 2)

            // Gloss
            Circle()
                .fill(
                    RadialGradient(
                        colors: [Color.white.opacity(0.5), .clear],
                        center: UnitPoint(x: 0.3, y: 0.25),
                        startRadius: 0,
                        endRadius: size * 0.45
                    )
                )
                .frame(width: size, height: size)

            Text(symbol)
                .font(.system(size: size * 0.38, weight: .bold, design: .rounded))
                .foregroundStyle(textColor)
        }
    }
}

struct KeyTermRow: View {
    let term: String
    let value: String

    var body: some View {
        HStack {
            Text(term)
                .fontWeight(.medium)
            Spacer()
            Text(value)
                .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(term): \(value)")
    }
}
