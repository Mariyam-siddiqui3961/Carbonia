import SwiftUI

// MARK: - Atom Sphere (2D with 3D sheen)

struct AtomSphereView: View {
    let color: Color
    let size: CGFloat
    let label: String
    var labelColor: Color = .white

    var body: some View {
        ZStack {
            sphereFill
                .overlay(glossShine)
                .frame(width: size, height: size)
                .shadow(color: Color.black.opacity(0.3), radius: 3, x: 2, y: 2)

            Text(label)
                .font(.system(size: size * 0.4, weight: .bold, design: .rounded))
                .foregroundStyle(labelColor.opacity(0.9))
                .shadow(color: Color.black.opacity(0.2), radius: 1, x: 1, y: 1)
        }
        .accessibilityLabel("\(label) atom")
    }

    private var sphereFill: some View {
        Circle().fill(
            RadialGradient(
                gradient: Gradient(colors: [color.opacity(0.4), color, color.opacity(0.8)]),
                center: .topLeading,
                startRadius: size * 0.1,
                endRadius: size * 0.9
            )
        )
    }

    private var glossShine: some View {
        Circle().fill(
            RadialGradient(
                gradient: Gradient(colors: [Color.white.opacity(0.7), .clear]),
                center: UnitPoint(x: 0.3, y: 0.3),
                startRadius: 0,
                endRadius: size * 0.4
            )
        )
    }
}

// MARK: - Bond Views

struct BondCylinderView: View {
    let color: Color
    let width: CGFloat
    let height: CGFloat
    let orientation: Orientation

    enum Orientation { case horizontal, vertical }

    var body: some View {
        let gradient = LinearGradient(
            gradient: Gradient(colors: [color.opacity(0.6), color.opacity(0.3), color.opacity(0.6)]),
            startPoint: orientation == .horizontal ? .top : .leading,
            endPoint: orientation == .horizontal ? .bottom : .trailing
        )
        RoundedRectangle(cornerRadius: orientation == .horizontal ? height/2 : width/2)
            .fill(color)
            .overlay(
                RoundedRectangle(cornerRadius: orientation == .horizontal ? height/2 : width/2)
                    .fill(gradient)
            )
            .frame(width: width, height: height)
    }
}

struct MultiBondView: View {
    let bondCount: Int
    let color: Color
    let length: CGFloat
    let thickness: CGFloat
    let orientation: BondCylinderView.Orientation

    var body: some View {
        switch orientation {
        case .horizontal:
            VStack(spacing: 4) {
                ForEach(0..<bondCount, id: \.self) { _ in
                    BondCylinderView(color: color, width: length, height: thickness, orientation: .horizontal)
                }
            }
        case .vertical:
            HStack(spacing: 4) {
                ForEach(0..<bondCount, id: \.self) { _ in
                    BondCylinderView(color: color, width: thickness, height: length, orientation: .vertical)
                }
            }
        }
    }
}

// MARK: - Chat Components

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let isUser: Bool
    let timestamp = Date()
}

struct ChatBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.isUser {
                Spacer(minLength: 60)
                Text(message.text)
                    .padding(12)
                    .background(Color.blue, in: RoundedRectangle(cornerRadius: 16).corners(.allCorners, except: .bottomRight))
                    .foregroundStyle(Color.white)
            } else {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 14))
                        .padding(8)
                        .background(Circle().fill(Color.purple.opacity(0.1)))
                        .foregroundStyle(Color.purple)

                    Text(message.text)
                        .padding(12)
                        .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 16).corners(.allCorners, except: .bottomLeft))
                        .foregroundStyle(Color.primary)
                }
                Spacer(minLength: 60)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(message.isUser ? "You: \(message.text)" : "AI: \(message.text)")
    }
}

struct LoadingBubble: View {
    @State private var phase = 0

    var body: some View {
        HStack {
            HStack(spacing: 5) {
                ForEach(0..<3, id: \.self) { i in
                    Circle()
                        .fill(Color.secondary)
                        .frame(width: 7, height: 7)
                        .scaleEffect(phase == i ? 1.3 : 0.8)
                        .animation(
                            .easeInOut(duration: 0.4).repeatForever().delay(Double(i) * 0.15),
                            value: phase
                        )
                }
            }
            .padding(14)
            .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 16))
            Spacer()
        }
        .onAppear { phase = 1 }
        .accessibilityLabel("AI is typing")
    }
}

// MARK: - Info / Rule Cards

struct RuleCard: View {
    let number: Int
    let title: String
    let description: String
    let icon: String
    let color: Color

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(spacing: 8) {
                ZStack {
                    Circle()
                        .fill(color.opacity(0.12))
                        .frame(width: 38, height: 38)
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(color)
                }
                Text("\(number)")
                    .font(.caption2.bold())
                    .foregroundStyle(Color.secondary)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Capsule().fill(Color.secondary.opacity(0.1)))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                Text(description)
                    .font(.subheadline)
                    .foregroundStyle(Color.secondary)
                    .lineSpacing(2)
            }

            Spacer()
        }
        .padding()
        .background(Theme.secondarySystemBackground)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Rule \(number): \(title). \(description)")
    }
}

// MARK: - Corner Radius Helpers

extension RoundedRectangle {
    func corners(_ all: UIRectCorner, except corner: UIRectCorner) -> some Shape {
        self
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}
