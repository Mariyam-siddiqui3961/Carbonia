import SwiftUI

// MARK: - Main View

@available(iOS 17.0, *)
struct CarbonElementView: View {
    @State private var show3DModel = false
    @State private var showDetail = false

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {

                HStack {
                    Spacer()
                    CarbonPeriodicTile()
                        .onTapGesture { showDetail = true }
                    Spacer()
                }

                sectionHeader("Atomic Structure")
                AtomicStructureSection(show3DModel: $show3DModel)

                sectionHeader("Covalent Bonding")
                CovalentBondingSection()

            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .navigationTitle("Carbon")
        .navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $showDetail) {
            CarbonDetailSheet()
        }
        .sheet(isPresented: $show3DModel) {
            NavigationStack {
                CarbonAtomView()
                    .ignoresSafeArea()
                    .navigationTitle("3D Atomic Model")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Done") { show3DModel = false }
                        }
                    }
            }
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
    }

    private func sectionHeader(_ title: String) -> some View {
        HStack {
            Text(title)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(Color(uiColor: .label))
            Spacer()
        }
    }
}

// MARK: - Section 1: Periodic Tile

struct CarbonPeriodicTile: View {
    private let tileSize: CGFloat = 150
    private let grad = LinearGradient(
        colors: [Color(red: 0.22, green: 0.45, blue: 0.95),
                 Color(red: 0.38, green: 0.25, blue: 0.92)],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(grad)
                .frame(width: tileSize, height: tileSize)
                .shadow(color: Color(red: 0.22, green: 0.45, blue: 0.95).opacity(0.45),
                        radius: 16, x: 0, y: 8)

            // Atomic number — top left
            Text("6")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundColor(Color.white.opacity(0.88))
                .frame(width: tileSize, height: tileSize, alignment: .topLeading)
                .padding(.top, 22).padding(.leading, 22)

            // Atomic mass — top right
            Text("12.011")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundColor(Color.white.opacity(0.88))
                .frame(width: tileSize, height: tileSize, alignment: .topTrailing)
                .padding(.top, 22).padding(.trailing, 22)

            // Symbol — centre
            Text("C")
                .font(.system(size: 72, weight: .bold, design: .rounded))
                .foregroundColor(Color.white)

            // Element name — bottom centre
            Text("Carbon")
                .font(.system(size: 15, weight: .medium, design: .rounded))
                .foregroundColor(Color.white.opacity(0.9))
                .frame(width: tileSize, height: tileSize, alignment: .bottom)
                .padding(.bottom, 12)
        }
        .frame(width: tileSize, height: tileSize)
        .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .accessibilityLabel("Carbon element tile, atomic number 6, mass 12.011. Tap for details.")
        .accessibilityAddTraits(.isButton)
    }
}

// MARK: - Section 2: Atomic Structure

@available(iOS 17.0, *)
struct AtomicStructureSection: View {
    @Binding var show3DModel: Bool

    private let grad = LinearGradient(
        colors: [Color(red: 0.22, green: 0.45, blue: 0.95),
                 Color(red: 0.38, green: 0.25, blue: 0.92)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    var body: some View {
        VStack(spacing: 0) {
            shellDiagram
            Divider()
            configRow
        }
        .background(Color(uiColor: .secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: Color.black.opacity(0.06), radius: 10, x: 0, y: 4)
    }

    private var shellDiagram: some View {
        ZStack(alignment: .topTrailing) {
            ShellDiagramCore()
                .frame(maxWidth: .infinity)
                .padding(.vertical, 24)
            threeDButton
        }
    }

    private var threeDButton: some View {
        Button { show3DModel = true } label: {
            Text("3D")
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundColor(Color.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(grad)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .shadow(color: Color(red: 0.22, green: 0.45, blue: 0.95).opacity(0.4),
                        radius: 6, x: 0, y: 3)
        }
        .padding(14)
        .accessibilityLabel("View 3D atomic model")
    }

    private var configRow: some View {
        HStack(spacing: 0) {
            configCell(top: "Configuration", bottom: "2, 4")
            Divider().frame(height: 36)
            configCell(top: "Notation", bottom: "1s² 2s² 2p²")
            Divider().frame(height: 36)
            configCell(top: "Valence e⁻", bottom: "4")
            Divider().frame(height: 36)
            configCell(top: "Shells", bottom: "K(2)  L(4)")
        }
        .padding(.vertical, 14)
    }

    private func configCell(top: String, bottom: String) -> some View {
        VStack(spacing: 3) {
            Text(top)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(Color(uiColor: .secondaryLabel))
            Text(bottom)
                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                .foregroundColor(Color(uiColor: .label))
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Interactive Shell Diagram

@available(iOS 17.0, *)
struct ShellDiagramCore: View {
    @State private var kAngle: Double = 0
    @State private var lAngle: Double = 0
    @State private var tappedShell: String? = nil
    @State private var nucleusTapped: Bool = false

    private let timer = Timer.publish(every: 0.016, on: .main, in: .common).autoconnect()
    private let kColor = Color(red: 0.22, green: 0.55, blue: 0.95)
    private let lColor = Color(red: 0.9,  green: 0.3,  blue: 0.3)
    private let nuclearColor = Color(red: 0.55, green: 0.28, blue: 0.95)

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                tappableNucleus
                TappableShellRing(
                    radius: 60, electrons: 2, shellLabel: "K",
                    color: kColor, baseAngle: $kAngle,
                    isTapped: tappedShell == "K"
                ) { tappedShell = tappedShell == "K" ? nil : "K"; nucleusTapped = false }

                TappableShellRing(
                    radius: 104, electrons: 4, shellLabel: "L",
                    color: lColor, baseAngle: $lAngle,
                    isTapped: tappedShell == "L"
                ) { tappedShell = tappedShell == "L" ? nil : "L"; nucleusTapped = false }
            }
            .frame(width: 230, height: 230)
            .onReceive(timer) { _ in
                kAngle += 1.8
                lAngle += 1.0
            }

            // Info bubble
            if nucleusTapped {
                nucleusInfoBubble
                    .transition(.scale.combined(with: .opacity))
                    .padding(.top, 8)
            } else if let shell = tappedShell {
                shellInfoBubble(shell: shell)
                    .transition(.scale.combined(with: .opacity))
                    .padding(.top, 8)
            } else {
                Text("Tap the nucleus or shells to explore")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(Color(uiColor: .tertiaryLabel))
                    .padding(.top, 8)
            }
        }
        .animation(.spring(response: 0.35), value: tappedShell)
        .animation(.spring(response: 0.35), value: nucleusTapped)
        .padding(.vertical, 16)
        .frame(maxWidth: .infinity)
    }

    private var tappableNucleus: some View {
        ZStack {
            // Pulse ring when tapped
            if nucleusTapped {
                Circle()
                    .stroke(nuclearColor.opacity(0.4), lineWidth: 2)
                    .frame(width: 60, height: 60)
            }
            Circle()
                .fill(RadialGradient(
                    colors: [Color(red: 0.55, green: 0.28, blue: 0.95),
                             Color(red: 0.20, green: 0.10, blue: 0.65)],
                    center: .center, startRadius: 0, endRadius: 22))
                .frame(width: 44, height: 44)
                .shadow(color: nuclearColor.opacity(nucleusTapped ? 0.9 : 0.5), radius: nucleusTapped ? 14 : 10)
                .scaleEffect(nucleusTapped ? 1.15 : 1.0)
                .animation(.spring(response: 0.3), value: nucleusTapped)
            Text("C")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundColor(Color.white)
        }
        .contentShape(Circle().size(CGSize(width: 56, height: 56)))
        .onTapGesture {
            nucleusTapped.toggle()
            if nucleusTapped { tappedShell = nil }
        }
    }

    private var nucleusInfoBubble: some View {
        HStack(spacing: 10) {
            Circle().fill(nuclearColor).frame(width: 10, height: 10)
                .shadow(color: nuclearColor.opacity(0.6), radius: 4)
            VStack(alignment: .leading, spacing: 2) {
                Text("Nucleus — Carbon-12")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(nuclearColor)
                Text("6 protons  ·  6 neutrons  ·  Mass ≈ 12 u")
                    .font(.system(size: 11))
                    .foregroundColor(Color(uiColor: .secondaryLabel))
            }
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(nuclearColor.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .padding(.horizontal, 16)
    }

    private func shellInfoBubble(shell: String) -> some View {
        let isK = shell == "K"
        let color = isK ? kColor : lColor
        let title  = isK ? "K Shell — 1st Energy Level" : "L Shell — 2nd Energy Level"
        let detail = isK ? "2 electrons  ·  1s² orbital  ·  Full shell (stable inner core)" :
                           "4 electrons  ·  2s² 2p²  ·  4 valence electrons enable bonding"
        return HStack(spacing: 10) {
            Circle().fill(color).frame(width: 10, height: 10)
                .shadow(color: color.opacity(0.6), radius: 4)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(color)
                Text(detail)
                    .font(.system(size: 11))
                    .foregroundColor(Color(uiColor: .secondaryLabel))
            }
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(color.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .padding(.horizontal, 16)
    }
}

@available(iOS 17.0, *)
struct TappableShellRing: View {
    let radius: CGFloat
    let electrons: Int
    let shellLabel: String
    let color: Color
    @Binding var baseAngle: Double
    let isTapped: Bool
    let onTap: () -> Void

    // Hit zone: annular band ±20pt around the ring radius
    private let hitBand: CGFloat = 22

    var body: some View {
        ZStack {
            // Invisible annular hit zone — only the ring band, not full circle
            Circle()
                .stroke(Color.clear, lineWidth: hitBand * 2)
                .frame(width: radius * 2, height: radius * 2)
                .contentShape(Circle().stroke(lineWidth: hitBand * 2))
                .onTapGesture { onTap() }

            // Visible orbit ring
            Circle()
                .stroke(color.opacity(isTapped ? 0.65 : 0.25),
                        lineWidth: isTapped ? 2.5 : 1.5)
                .frame(width: radius * 2, height: radius * 2)
                .animation(.easeInOut(duration: 0.2), value: isTapped)

            // Shell label
            Text(shellLabel)
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(color.opacity(0.75))
                .offset(x: radius - 8, y: 0)

            // Electrons
            ForEach(0..<electrons, id: \.self) { i in
                let angle = baseAngle * .pi / 180
                    + 2 * .pi * Double(i) / Double(electrons)
                ZStack {
                    Circle()
                        .fill(color)
                        .frame(width: isTapped ? 15 : 12,
                               height: isTapped ? 15 : 12)
                        .shadow(color: color.opacity(isTapped ? 1.0 : 0.7),
                                radius: isTapped ? 8 : 4)
                    Circle().fill(Color.white.opacity(0.4))
                        .frame(width: 5, height: 5)
                        .offset(x: -2, y: -2)
                }
                .offset(x: CGFloat(cos(angle)) * radius,
                        y: CGFloat(sin(angle)) * radius)
                .animation(.easeInOut(duration: 0.2), value: isTapped)
            }
        }
        // Do NOT set a broad contentShape here — let the inner stroke handle it
        .allowsHitTesting(true)
    }
}

struct ShellRing: View {
    let radius: CGFloat
    let electrons: Int
    let shellLabel: String
    let color: Color
    var body: some View { EmptyView() } // legacy stub
}

struct Electron: View {
    let color: Color
    var body: some View {
        ZStack {
            Circle().fill(color).frame(width: 12, height: 12)
            Circle().fill(Color.white.opacity(0.4)).frame(width: 5, height: 5)
                .offset(x: -2, y: -2)
        }
        .shadow(color: color.opacity(0.7), radius: 4)
    }
}

// MARK: - Section 3: Covalent Bonding (Interactive)

@available(iOS 17.0, *)
struct CovalentBondingSection: View {
    @State private var step: Int = 0   // 0=methane, 1=bonding formation, 2=electricity test

    private let steps = ["Structure", "Bonding", "Electricity"]

    var body: some View {
        VStack(spacing: 0) {
            // Step picker
            Picker("", selection: $step) {
                ForEach(0..<steps.count, id: \.self) { i in
                    Text(steps[i]).tag(i)
                }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 2)

            // Content by step
            Group {
                switch step {
                case 0: MethaneStructureView()
                case 1: BondFormationView()
                default: ElectricityTestView()
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 280)
            .animation(.easeInOut(duration: 0.35), value: step)

            Divider()
            bondInfoRow
        }
        .background(Color(uiColor: .secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: Color.black.opacity(0.06), radius: 10, x: 0, y: 4)
    }

    private var bondInfoRow: some View {
        HStack(spacing: 0) {
            bondCell(label: "Bond Type", value: "Covalent")
            Divider().frame(height: 36)
            bondCell(label: "Bonds", value: "4")
            Divider().frame(height: 36)
            bondCell(label: "Molecule", value: "CH₄")
            Divider().frame(height: 36)
            bondCell(label: "Conducts?", value: "No ✗")
        }
        .padding(.vertical, 14)
    }

    private func bondCell(label: String, value: String) -> some View {
        VStack(spacing: 3) {
            Text(label)
                .font(.system(size: 10, weight: .medium))
                .foregroundColor(Color(uiColor: .secondaryLabel))
            Text(value)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(uiColor: .label))
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: Step 0 — CH₄ Static Structure
@available(iOS 17.0, *)
struct MethaneStructureView: View {
    private let hPos: [CGSize] = [
        CGSize(width: 0, height: -96), CGSize(width: 0, height: 96),
        CGSize(width: -96, height: 0), CGSize(width: 96, height: 0),
    ]
    private let cR: CGFloat = 28
    private let hR: CGFloat = 22

    var body: some View {
        ZStack {
            ForEach(0..<4, id: \.self) { i in bondLine(hPos[i]) }
            ForEach(0..<4, id: \.self) { i in hAtom(hPos[i]) }
            cAtom
            caption("Methane — carbon shares 1 electron with each H")
        }
    }

    private func bondLine(_ pos: CGSize) -> some View {
        GeometryReader { g in
            let cx = g.size.width/2, cy = g.size.height/2
            let hx = cx+pos.width, hy = cy+pos.height
            let dx = hx-cx, dy = hy-cy
            let l = sqrt(dx*dx+dy*dy)
            Path { p in
                p.move(to: CGPoint(x: cx+dx/l*(cR+2), y: cy+dy/l*(cR+2)))
                p.addLine(to: CGPoint(x: hx-dx/l*(hR+2), y: hy-dy/l*(hR+2)))
            }.stroke(Color(uiColor: .systemGray3), style: StrokeStyle(lineWidth: 3, lineCap: .round))
        }
    }

    private func hAtom(_ pos: CGSize) -> some View {
        ZStack {
            Circle().fill(RadialGradient(colors: [Color(red:0.42,green:0.72,blue:1.0), Color(red:0.12,green:0.38,blue:0.85)], center:.center, startRadius:0, endRadius:hR))
                .frame(width: hR*2, height: hR*2).shadow(color: Color.blue.opacity(0.35), radius: 5)
            Text("H").font(.system(size:14, weight:.bold, design:.rounded)).foregroundColor(.white)
        }.offset(x: pos.width, y: pos.height)
    }

    private var cAtom: some View {
        ZStack {
            Circle().fill(RadialGradient(colors:[Color(red:0.55,green:0.28,blue:0.95),Color(red:0.20,green:0.10,blue:0.65)], center:.center, startRadius:0, endRadius:cR))
                .frame(width:cR*2, height:cR*2).shadow(color: Color.purple.opacity(0.5), radius:8)
            Text("C").font(.system(size:20, weight:.bold, design:.rounded)).foregroundColor(.white)
        }
    }

    private func caption(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 11, weight: .medium))
            .foregroundColor(Color(uiColor: .tertiaryLabel))
            .multilineTextAlignment(.center)
            .padding(.horizontal, 24)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            .padding(.bottom, 8)
    }
}

// MARK: Step 1 — Bond Formation Animation
@available(iOS 17.0, *)
struct BondFormationView: View {
    @State private var phase: Int = 0   // 0=apart, 1=approaching, 2=shared, 3=bonded
    @State private var sharedPulse = false
    private let timer2 = Timer.publish(every: 2.0, on: .main, in: .common).autoconnect()

    private let cColor = Color(red: 0.55, green: 0.28, blue: 0.95)
    private let hColor = Color(red: 0.22, green: 0.55, blue: 0.95)
    private let eColor = Color(red: 0.98, green: 0.82, blue: 0.22)

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                // C atom
                let cX: CGFloat = phase >= 1 ? -52 : -90
                atomView(label: "C", color: cColor, size: 52)
                    .offset(x: cX)
                    .animation(.spring(response: 0.6, dampingFraction: 0.75), value: phase)

                // H atom
                let hX: CGFloat = phase >= 1 ? 52 : 90
                atomView(label: "H", color: hColor, size: 40)
                    .offset(x: hX)
                    .animation(.spring(response: 0.6, dampingFraction: 0.75), value: phase)

                // C lone electron — moves toward centre
                if phase <= 1 {
                    electronDot(color: eColor)
                        .offset(x: phase == 0 ? -62 : -28, y: -14)
                        .animation(.spring(response: 0.5), value: phase)
                }

                // H lone electron — moves toward centre
                if phase <= 1 {
                    electronDot(color: eColor)
                        .offset(x: phase == 0 ? 58 : 28, y: 14)
                        .animation(.spring(response: 0.5), value: phase)
                }

                // Shared electron pair — appears at phase 2+
                if phase >= 2 {
                    HStack(spacing: 4) {
                        electronDot(color: eColor)
                        electronDot(color: eColor)
                    }
                    .scaleEffect(sharedPulse ? 1.3 : 1.0)
                    .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: sharedPulse)

                    // Bond line
                    Rectangle()
                        .fill(Color(uiColor: .systemGray3))
                        .frame(width: phase >= 3 ? 50 : 0, height: 3)
                        .clipShape(Capsule())
                        .animation(.easeInOut(duration: 0.4), value: phase)
                }
            }
            .frame(height: 200)

            // Step caption
            stepCaption
                .padding(.horizontal, 20)
                .padding(.bottom, 4)
        }
        .onReceive(timer2) { _ in
            withAnimation {
                phase = (phase + 1) % 4
                if phase == 2 { sharedPulse = true }
                else { sharedPulse = false }
            }
        }
        .onAppear { phase = 0 }
    }

    private var stepCaption: some View {
        let texts = [
            "① C has 4 valence electrons, H has 1",
            "② Atoms approach — electrons attract",
            "③ Electrons shared between both atoms ✦",
            "④ Covalent bond formed — stable molecule"
        ]
        return Text(texts[phase])
            .font(.system(size: 12, weight: .medium))
            .foregroundColor(Color(uiColor: .secondaryLabel))
            .multilineTextAlignment(.center)
            .animation(.easeInOut, value: phase)
    }

    private func atomView(label: String, color: Color, size: CGFloat) -> some View {
        ZStack {
            Circle().fill(RadialGradient(colors:[color.opacity(0.9), color.opacity(0.5)], center:.center, startRadius:0, endRadius:size/2))
                .frame(width:size, height:size)
                .shadow(color: color.opacity(0.45), radius: 8)
            Text(label).font(.system(size:size*0.38, weight:.bold, design:.rounded)).foregroundColor(.white)
        }
    }

    private func electronDot(color: Color) -> some View {
        Circle().fill(color).frame(width: 10, height: 10)
            .shadow(color: color.opacity(0.8), radius: 5)
    }
}

// MARK: Step 2 — No Electricity Demo
@available(iOS 17.0, *)
struct ElectricityTestView: View {
    @State private var switched = false
    @State private var electronPos: CGFloat = 0
    @State private var blocked = false

    private let wireColor = Color(uiColor: .systemGray4)
    private let eColor    = Color(red: 0.98, green: 0.82, blue: 0.22)

    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                // Circuit wire top
                RoundedRectangle(cornerRadius: 4)
                    .fill(wireColor)
                    .frame(width: 240, height: 5)
                    .offset(y: -40)

                // Battery left
                batteryView
                    .offset(x: -100, y: -40)

                // Bulb right
                bulbView
                    .offset(x: 100, y: -40)

                // Molecule in middle of wire
                moleculeBlock
                    .offset(y: -40)

                // Moving electron (only moves when switched on, then stops)
                Circle()
                    .fill(eColor)
                    .frame(width: 12, height: 12)
                    .shadow(color: eColor.opacity(0.8), radius: 6)
                    .offset(x: switched ? (blocked ? -28 : 100) : -100, y: -40)
                    .animation(switched
                        ? .linear(duration: blocked ? 0.4 : 1.5)
                        : .none, value: electronPos)

                // Wire bottom
                RoundedRectangle(cornerRadius: 4)
                    .fill(wireColor)
                    .frame(width: 240, height: 5)
                    .offset(y: 40)

                // Vertical wires connecting top/bottom
                RoundedRectangle(cornerRadius: 4)
                    .fill(wireColor).frame(width: 5, height: 80).offset(x: -120)
                RoundedRectangle(cornerRadius: 4)
                    .fill(wireColor).frame(width: 5, height: 80).offset(x: 120)
            }
            .frame(height: 160)

            // Switch
            HStack(spacing: 12) {
                Text(switched ? "Switch ON" : "Switch OFF")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(switched ? Color.green : Color(uiColor: .secondaryLabel))
                Toggle("", isOn: $switched)
                    .labelsHidden()
                    .tint(Color.green)
                    .onChange(of: switched) {
                        if switched {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                blocked = true
                            }
                        } else {
                            blocked = false
                        }
                    }
            }
            .padding(.horizontal, 24)

            // Result label
            Text(switched
                 ? "⚡ Electron blocked by covalent molecule — no free electrons to carry charge"
                 : "Covalent bonds hold electrons tightly — none are free to flow")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(switched ? Color.orange : Color(uiColor: .tertiaryLabel))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
                .animation(.easeInOut, value: switched)
        }
    }

    private var batteryView: some View {
        VStack(spacing: 2) {
            Image(systemName: "battery.100").font(.system(size: 22)).foregroundColor(.green)
            Text("+ −").font(.system(size: 9, weight: .bold)).foregroundColor(.green)
        }
    }

    private var bulbView: some View {
        VStack(spacing: 2) {
            Image(systemName: switched && !blocked ? "lightbulb.fill" : "lightbulb")
                .font(.system(size: 22))
                .foregroundColor(switched && !blocked ? .yellow : Color(uiColor: .systemGray3))
                .animation(.easeInOut(duration: 0.3), value: blocked)
            Text("Bulb").font(.system(size: 9, weight: .medium)).foregroundColor(Color(uiColor: .secondaryLabel))
        }
    }

    private var moleculeBlock: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(Color(red: 0.55, green: 0.28, blue: 0.95).opacity(0.15))
                .frame(width: 48, height: 28)
            Text("CH₄")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundColor(Color(red: 0.55, green: 0.28, blue: 0.95))
        }
    }
}

// MARK: - Detail Sheet

@available(iOS 17.0, *)
struct CarbonDetailSheet: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                tileSection
                generalSection
                scientificSection
                physicalSection
                historySection
                isotopesSection
                wikiSection
            }
            .navigationTitle("Carbon")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }.fontWeight(.semibold)
                }
            }
        }
    }

    private var tileSection: some View {
        Section {
            HStack { Spacer(); SmallPeriodicTile(); Spacer() }
                .listRowBackground(Color.clear)
                .padding(.vertical, 8)
        }
    }

    private var generalSection: some View {
        Section(header: Text("General")) {
            DetailRow(label: "Name",          value: "Carbon")
            DetailRow(label: "Symbol",        value: "C")
            DetailRow(label: "Atomic Number", value: "6")
            DetailRow(label: "Atomic Mass",   value: "12.011 u")
            DetailRow(label: "Category",      value: "Nonmetal")
            DetailRow(label: "Group",         value: "14 (Carbon group)")
            DetailRow(label: "Period",        value: "2")
            DetailRow(label: "Block",         value: "p-block")
        }
    }

    private var scientificSection: some View {
        Section(header: Text("Scientific Properties")) {
            DetailRow(label: "Electron Config",   value: "1s² 2s² 2p²")
            DetailRow(label: "Shorthand Config",  value: "[He] 2s² 2p²")
            DetailRow(label: "Valence Electrons", value: "4")
            DetailRow(label: "Electronegativity", value: "2.55 (Pauling)")
            DetailRow(label: "Bonding Type",      value: "Covalent")
            DetailRow(label: "Oxidation States",  value: "+4, +2, -4")
            DetailRow(label: "Noble Gas Config",  value: "[He] + 2s² 2p²")
        }
    }

    private var valenceSection: some View {
        Section(header: Text("Why 4 Valence Electrons?")) {
            ValenceExplainerCell()
        }
    }

    private var covalentSection: some View {
        Section(header: Text("Covalent Bonding")) {
            DetailRow(label: "Bond Type",   value: "Covalent (shares electrons)")
            DetailRow(label: "Max Bonds",   value: "4 (tetravalent)")
            DetailRow(label: "Single Bond", value: "C–C  e.g. Ethane (C₂H₆)")
            DetailRow(label: "Double Bond", value: "C=C  e.g. Ethene (C₂H₄)")
            DetailRow(label: "Triple Bond", value: "C≡C  e.g. Ethyne (C₂H₂)")
            CovalentExplainerCell()
        }
    }

    private var effectsSection: some View {
        Section(header: Text("Effect of 4 Valence Electrons")) {
            BulletRow(icon: "atom",       text: "Tetravalency — bonds with 4 atoms simultaneously, enabling branched & ring structures.")
            BulletRow(icon: "link",       text: "Catenation — forms long C–C chains (hydrocarbons, polymers, DNA backbone).")
            BulletRow(icon: "cube",       text: "Tetrahedral geometry — sp³ hybridisation gives 109.5° bond angles.")
            BulletRow(icon: "sparkles",   text: "Allotropy — same element, wildly different structures: diamond, graphite, fullerene, graphene.")
            BulletRow(icon: "heart.fill", text: "Basis of life — carbon's versatility is why all known life is carbon-based.")
        }
    }

    private var physicalSection: some View {
        Section(header: Text("Physical Attributes")) {
            DetailRow(label: "Phase at STP",         value: "Solid")
            DetailRow(label: "Appearance",           value: "Black (graphite) / Clear (diamond)")
            DetailRow(label: "Density (graphite)",   value: "2.267 g/cm³")
            DetailRow(label: "Density (diamond)",    value: "3.515 g/cm³")
            DetailRow(label: "Melting Point",        value: "3,642 °C (sublimes)")
            DetailRow(label: "Boiling Point",        value: "4,827 °C")
            DetailRow(label: "Hardness (diamond)",   value: "10 / 10 (Mohs scale)")
            DetailRow(label: "Thermal Conductivity", value: "Diamond: highest known")
        }
    }

    private var historySection: some View {
        Section(header: Text("History & Overview")) {
            DetailRow(label: "Discovered", value: "Prehistoric (charcoal, soot)")
            DetailRow(label: "Named by",   value: "Antoine Lavoisier, 1789")
            DetailRow(label: "From Latin", value: "\"carbo\" (charcoal / coal)")
            HistoryOverviewCell()
        }
    }

    private var isotopesSection: some View {
        Section(header: Text("Isotopes")) {
            DetailRow(label: "¹²C", value: "98.89% — stable, mass standard")
            DetailRow(label: "¹³C", value: "1.11% — stable, NMR spectroscopy")
            DetailRow(label: "¹⁴C", value: "Trace — radioactive, carbon dating")
        }
    }

    private var natureSection: some View {
        Section(header: Text("Carbon in Nature & Technology")) {
            BulletRow(icon: "leaf.fill",    text: "Carbon cycle — photosynthesis & respiration keep atmospheric CO₂ in balance.")
            BulletRow(icon: "flame.fill",   text: "Fossil fuels — coal, oil, gas are all carbon-based energy stores.")
            BulletRow(icon: "clock.fill",   text: "Carbon dating — ¹⁴C decay used to date organic material up to ~50,000 years old.")
            BulletRow(icon: "bolt.fill",    text: "Carbon nanotubes — 100× stronger than steel, excellent conductors.")
            BulletRow(icon: "diamond.fill", text: "Diamond — hardest natural material, used in cutting tools & jewellery.")
            BulletRow(icon: "pencil",       text: "Graphite — soft, conducts electricity, used in pencils & batteries.")
        }
    }

    private var wikiSection: some View {
        Section {
            Link(destination: URL(string: "https://en.wikipedia.org/wiki/Carbon")!) {
                HStack {
                    Image(systemName: "globe").foregroundColor(Color.blue)
                    Text("Read more on Wikipedia").foregroundColor(Color.blue)
                    Spacer()
                    Image(systemName: "arrow.up.right").foregroundColor(Color.blue).font(.caption)
                }
            }
        }
    }
}

// MARK: - Small Tile (sheet header)

struct SmallPeriodicTile: View {
    private let grad = LinearGradient(
        colors: [Color(red: 0.22, green: 0.45, blue: 0.95),
                 Color(red: 0.38, green: 0.25, blue: 0.92)],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(grad).frame(width: 120, height: 120)
            numberLabel; massLabel; symbolLabel; nameLabel
        }
        .frame(width: 120, height: 120)
    }

    private var numberLabel: some View {
        Text("6")
            .font(.system(size: 13, weight: .semibold, design: .rounded))
            .foregroundColor(Color.white.opacity(0.85))
            .frame(width: 120, height: 120, alignment: .topLeading)
            .padding(.top, 14).padding(.leading, 14)
    }
    private var massLabel: some View {
        Text("12.011")
            .font(.system(size: 13, weight: .semibold, design: .rounded))
            .foregroundColor(Color.white.opacity(0.85))
            .frame(width: 120, height: 120, alignment: .topTrailing)
            .padding(.top, 14).padding(.trailing, 14)
    }
    private var symbolLabel: some View {
        Text("C")
            .font(.system(size: 58, weight: .bold, design: .rounded))
            .foregroundColor(Color.white)
    }
    private var nameLabel: some View {
        Text("Carbon")
            .font(.system(size: 13, weight: .medium, design: .rounded))
            .foregroundColor(Color.white.opacity(0.88))
            .frame(width: 120, height: 120, alignment: .bottom)
            .padding(.bottom, 10)
    }
}

// MARK: - Reusable Cell Sub-views

struct ValenceExplainerCell: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Carbon sits in Group 14, meaning its outermost shell (n=2) holds exactly 4 electrons out of a possible 8. This half-filled shell is the key to everything:")
                .font(.subheadline)
                .foregroundColor(Color(uiColor: .label))
            BulletText("It is equally easy to gain 4 electrons or lose 4 — neither is energetically favourable, so carbon prefers to share.")
            BulletText("Sharing gives each atom a full octet without the large energy cost of ionic transfer.")
            BulletText("With 4 bonding slots, carbon can form single, double, or triple bonds with up to 4 atoms simultaneously.")
        }
        .padding(.vertical, 4)
    }
}

struct CovalentExplainerCell: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Why covalent and not ionic?")
                .font(.subheadline).fontWeight(.medium)
            BulletText("Carbon's electronegativity (2.55) is close to hydrogen (2.20) — electrons are shared equally rather than transferred.")
            BulletText("Its small atomic radius means bonding electrons are held close and tightly, giving short, strong, directional bonds.")
        }
        .padding(.vertical, 4)
    }
}

struct HistoryOverviewCell: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Overview").font(.subheadline).fontWeight(.medium)
            Text("Carbon is the 15th most abundant element in Earth's crust and the 4th most abundant in the universe by mass. It forms a dedicated branch of chemistry — organic chemistry — because of its unparalleled ability to form long chains and complex molecules.")
                .font(.subheadline)
                .foregroundColor(Color(uiColor: .secondaryLabel))
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Shared Row Components

struct DetailRow: View {
    let label: String
    let value: String
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(Color(uiColor: .label))
            Spacer()
            Text(value)
                .font(.subheadline)
                .foregroundColor(Color(uiColor: .secondaryLabel))
                .multilineTextAlignment(.trailing)
        }
    }
}

struct BulletText: View {
    let text: String
    init(_ text: String) { self.text = text }
    var body: some View {
        HStack(alignment: .top, spacing: 6) {
            Text("•").foregroundColor(Color(red: 0.22, green: 0.45, blue: 0.95))
            Text(text).font(.subheadline).foregroundColor(Color(uiColor: .secondaryLabel))
        }
    }
}

struct BulletRow: View {
    let icon: String
    let text: String
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(Color(red: 0.22, green: 0.45, blue: 0.95))
                .frame(width: 20)
            Text(text).font(.subheadline).foregroundColor(Color(uiColor: .label))
        }
        .padding(.vertical, 2)
    }
}
