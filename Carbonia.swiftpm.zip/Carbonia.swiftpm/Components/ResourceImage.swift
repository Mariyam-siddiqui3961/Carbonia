// ResourceImage.swift — replaced by standard SwiftUI Image("name") from Assets.xcassets
import SwiftUI
